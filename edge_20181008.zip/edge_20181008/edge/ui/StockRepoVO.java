package com.boot.edge.ui;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Stocks")
public class StockRepoVO {

	private String dtdRange;
	
	List<StockVO> stock;

	public String getDtdRange() {
		return dtdRange;
	}

	public void setDtdRange(String dtdRange) {
		this.dtdRange = dtdRange;
	}

	@Override
	public String toString() {
		return "StockRepoVO [dtdRange=" + dtdRange + "]";
	}

	@XmlElement
	public List<StockVO> getStock() {
		return stock;
	}

	public void setStock(List<StockVO> stock) {
		this.stock = stock;
	}
		
}
