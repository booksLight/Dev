package com.boot.edge.ui;

public class ItemVO {
		
	private String codeUI;	
	private String titleUI;	
	private Double discountUI;	
	private String discriptionUI;
	private String productType;
	private Long productId;
	
	public String getCodeUI() {
		return codeUI;
	}
	public void setCodeUI(String codeUI) {
		this.codeUI = codeUI;
	}
	public String getTitleUI() {
		return titleUI;
	}
	public void setTitleUI(String titleUI) {
		this.titleUI = titleUI;
	}
	public Double getDiscountUI() {
		return discountUI;
	}
	public void setDiscountUI(Double discountUI) {
		this.discountUI = discountUI;
	}
	public String getDiscriptionUI() {
		return discriptionUI;
	}
	public void setDiscriptionUI(String discriptionUI) {
		this.discriptionUI = discriptionUI;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	@Override
	public String toString() {
		return "ItemVO [codeUI=" + codeUI + ", titleUI=" + titleUI + ", discountUI=" + discountUI + ", discriptionUI="
				+ discriptionUI + ", productType=" + productType + ", productId=" + productId + "]";
	}
		
}
