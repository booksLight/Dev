$(document).ready(function() {
	var table ="";
	
	var stocks = ""; 
	var stock =  "";
	var sdesc = "";
	var sqty = "";
	var suom = "";
	var svalue = "";
	var str ="";
	
	
			
	
	$('#add2Cart').click(function(e) { 
		table = document.getElementById("ecart");
	     
	       stocks = document.getElementById("selectStock"); 
	       stock =  stocks.options[stocks.selectedIndex];
	       sdesc = document.getElementById("stockDiscription").value;
	       sqty = document.getElementById("stockQty").value;
	       suom = document.getElementById("stockUom").value;
	       svalue = document.getElementById("stockSum").value; 	
	  
	  			
	  	str = stock.text + ", "+sdesc+", "+sqty+ ", "+suom+ ", "+svalue;	
	  	
	  	alert(str);
	      append(table);
	    });



function append(table){    
	var tr = createTR();
		
    	tr.appendChild(createTDStock("10%")); 
    	tr.appendChild(createTDDesc("15%"));    
    	tr.appendChild(createTDQty("20%"));
    	tr.appendChild(createTDUom("20%"));
    	tr.appendChild(createTDValue("15%"));
    	tr.appendChild(createTD("20%"));
    	tr.style.border = "1"; 
    	
      table.appendChild(tr);
  	alert(str);
}

function createTR(){
	return document.createElement("tr");
}

function createTD(s){	
	var td = document.createElement("td");
	td.style.width = s;
	td.style.border = "1"; 	
	td.appendChild(createNodeCommon(1));
	return td;
}

function createTDStock(s){	
	var td = document.createElement("td");
	td.style.width = s;
	td.style.border = "1"; 	
	td.appendChild(createNodeStock(1));
	return td;
}

function createTDDesc(s){	
	var td = document.createElement("td");
	td.style.width = s;
	td.style.border = "1"; 	
	td.appendChild(createNodeSdesc(2));
	return td;
}

function createTDQty(s){	
	var td = document.createElement("td");
	td.style.width = s;
	td.style.border = "1"; 	
	td.appendChild(createNodeSqty(3));
	return td;
}

function createTDUom(s){	
	var td = document.createElement("td");
	td.style.width = s;
	td.style.border = "1"; 	
	td.appendChild(createNodeSuom(4));
	return td;
}

function createTDValue(s){	
	var td = document.createElement("td");
	td.style.width = s;
	td.style.border = "1"; 	
	td.appendChild(createNodeSvalue(5));
	return td;
}

function createNodeStock(v){	
	return document.createTextNode(stock.text +":"+v);
}
function createNodeSdesc(v){	
	return document.createTextNode(sdesc +":"+v);
}

function createNodeSqty(v){	
	return document.createTextNode(sqty +":"+v);
}

function createNodeSuom(v){	
	return document.createTextNode(suom +":"+v);
}

function createNodeSvalue(v){	
	return document.createTextNode(svalue +":"+v);
}
function createNodeCommon(v){	
	return document.createTextNode(v);
}

} );