$(document).ready(
		function() {

			var findItemURL = "/item/list/";
			
			// START : Fetching Items based on product : Author@Raesh			
			$("#selectProduct").change(
					function() {
						debugger;
						var prodId = $("#selectProduct option:selected").val();
						console.log("selected Product =" + prodId);

						$.ajax({
							url : findItemURL + prodId,
							type : 'POST',
							success : function(result) {
								$("#selectItem").html("");
								$.each(result, function(key, val) {
									$("#selectItem").append(
											$('<option></option>').val(key)
													.html(val))
								})
							},
							error : function() {
								alert("Whooaaa! Something went wrong..")
							},
						});
					});
			 // END :Fetching Items based on product : Author@Raesh	
			
			
		});