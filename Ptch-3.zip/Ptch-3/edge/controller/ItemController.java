package com.boot.edge.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.boot.edge.model.Item;
import com.boot.edge.model.Product;
import com.boot.edge.model.master.MasterItem;
import com.boot.edge.model.master.MasterProduct;
import com.boot.edge.ui.ItemVO;
import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;
import com.boot.edge.util.ItemUtil;

@Controller
@RequestMapping("/item")
public class ItemController {

	@Autowired
	private ProductApi productApi;

	@Autowired
	private ItemApi itemApi;

	@GetMapping("/add")
	public String loadItemVoucher(Model model) {
		Map<Long, String> productMap = null;
		List<MasterProduct> mproductType = productApi.masterProducts();

		if (mproductType != null) {
			productMap = new HashMap<>();
			for (MasterProduct product : mproductType) {
				productMap.put(product.getId(), product.getTitle());
			}
		}

		model.addAttribute("products", productMap);
		model.addAttribute("item", new ItemVO());
		return "addItem";
	}

	@PostMapping("/add")
	public String addItemVoucher(@ModelAttribute ItemVO itemVO) {
		 itemApi.addMasterItem(transformItem(itemVO));		
		 return "redirect:/home";
	}

	private MasterItem transformItem(ItemVO itemVO) {
		System.out.println("\n MasterVO Item = "+itemVO.toString());
		MasterItem mItem = new MasterItem();
		mItem.setCode(itemVO.getCodeUI());
		mItem.setTitle(itemVO.getTitleUI());		
		mItem.setDiscription(itemVO.getDiscriptionUI());
		mItem.setDiscount(itemVO.getDiscountUI() !=null ? itemVO.getDiscountUI():0.0);
		mItem.setProdId(itemVO.getProductId());
		mItem.setProdId(itemVO.getProductId());
		System.out.println("\n Master Item = "+mItem.toString());
		return mItem;
	}

	@GetMapping("/search")
	public void searchItem() {
		Long key = 1l;
		itemApi.findItem(key);
	}

	@GetMapping("/list")
	public void listItems() {
		List<Item> items = itemApi.items();
		if (items != null) {
			System.out.println(" t ****** Listing Items : STRT");
			for (Item it : items) {
				System.out.println(
						it.getId() + " " + it.getNumber() + " " + it.getQty() + " " + it.getStocks().toString());
			}
			System.out.println(" t ****** Listing Items : END");
		} else {
			System.out.println("Item not founds.");
		}
	}

	@GetMapping("/update")
	public void updateItem() {
		Item itm = new ItemUtil().initItem();
		itm.setId(1l);
		itm.setNumber(itm.getNumber() + 10);
		itm.setDiscription(itm.getDiscription() + " Updated one..");
		itemApi.updateItem(itm);
		System.out.println("Item " + itm.getId() + " updated successfully.");

	}

	@GetMapping("/delete")
	public void removeItem() {
		itemApi.updateItem(new Item());
	}

	@PostMapping(value = "/list/{id}")
	@ResponseBody
	public Map<Long, String> findListById(@PathVariable("id") Long key) throws Exception {

		Map<Long, String> itemMap = new HashMap<Long, String>();
		Item item = itemApi.findItem(key);
		if (item != null) {
			itemMap.put(item.getId(), item.getType());				
		} else {
			System.out.println("Ite not founds.");
		}
		return itemMap;
	}

	// https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram

}
