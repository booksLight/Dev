package com.boot.edge.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.boot.edge.model.Inventory;
import com.boot.edge.model.Item;
import com.boot.edge.model.Product;
import com.boot.edge.model.master.MasterProduct;
import com.boot.edge.ui.ProductVO;
import com.boot.edge.ui.Voucher;
import com.boot.edge.mgr.InvtApi;
import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;

@Controller
@RequestMapping("/mproduct")
public class ProductController {

	@Autowired
	private InvtApi invtApi;
	
	@Autowired
	private ProductApi productApi;
	
	@Autowired
	private ItemApi itemApi;

	@RequestMapping(value={"/add"}, method = RequestMethod.GET)
	public String loadProductVoucher(Model model) {
		
		Map<Long, String> productMap = null;
		model.addAttribute("voucher", new ProductVO());

		
		List<MasterProduct> mproductType = productApi.masterProducts();
		if(mproductType !=null) {
			productMap = new HashMap<>();
			for(MasterProduct product : mproductType) {			
				productMap.put(product.getId(), product.getTitle());
			}
		}
	
		model.addAttribute("products", productMap);
		return "addProduct";	
	}
	
	
	@RequestMapping(value={"/add"}, method = RequestMethod.POST)
	public String addProduct(@ModelAttribute ProductVO productVo ) {	
		System.out.println("\n **** addProduct :"+productVo.toString());
		productApi.addMasterProduct(transform(productVo));
		return "redirect:/home";
	}
		
	private MasterProduct transform(ProductVO productVo) {
		MasterProduct mp = new MasterProduct();
		mp.setCode(productVo.getCode());
		mp.setTitle(productVo.getTitle());		
		mp.setComments(productVo.getComments());
		mp.setStamp(productVo.getStamp());
		mp.setIsActive(productVo.getIsActive());		
		return mp;
	}


	@RequestMapping(value={"/list"}, method = RequestMethod.GET)
	public void showMasterProducts() {
		System.out.println(" \n\t ********** Searching  Product ********.");
		List<MasterProduct> mproductType = productApi.masterProducts();
		if (mproductType != null) {
		for (MasterProduct product : mproductType) {
			System.out.println(product.toString());
		}
		}else {
			System.out.println("Product not registered.");
		}
	}
	
	
	@PostMapping(value = "/list/{id}")
	@ResponseBody
	public Map<Long, String> findMasterProductById(@PathVariable("id") Long key) throws Exception {

		Map<Long, String> masterProductMap = new HashMap<Long, String>();
		
		MasterProduct mproduct = productApi.findMasterProduct(key);
		if (mproduct != null) {
			masterProductMap.put(mproduct.getId(), mproduct.getTitle());				
		} else {
			System.out.println("Product not registered.");
		}
		
		return masterProductMap;
	}
	
	//@RequestMapping(value={"/add"}, method = RequestMethod.POST)
	public void addInventory() {
		Inventory invtPram = new Inventory();
		invtApi.addInventory(invtPram);		
	}


	


	
	

	//https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram
	
}
