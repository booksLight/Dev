package com.boot.edge.util;

import com.boot.edge.model.MProduct;
import com.boot.edge.model.Product;
import com.boot.edge.ui.ProductVO;

public class TransformUtil {

	public Product transform(ProductVO productVO, Product product) {
		MProduct mproduct = new MProduct();
		
		return product;
	}

	
}
