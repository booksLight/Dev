package com.boot.edge.mgr;

import java.util.List;
import com.boot.edge.model.Stock;
import com.boot.edge.model.master.MasterStock;

public interface StockApi {

	public void addMasterStock(MasterStock mstock);
	public MasterStock findMasterStock(Long mstockKey);
	public List<MasterStock> mstocks();
	public void updateMasterStock(MasterStock mstock);
	public void deleteMasterStock(Long mstockKey);
	
	public void addStock(Stock stock);
	public Stock findStock(Long key);
	public List<Stock> stocks();
	public void updateStock(Stock stock);
	public void deleteStock(Long key);
}
