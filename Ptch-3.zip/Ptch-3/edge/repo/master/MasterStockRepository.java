package com.boot.edge.repo.master;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.boot.edge.model.master.MasterStock;

@Repository
public interface MasterStockRepository extends JpaRepository<MasterStock, Long>{

	MasterStock findInventoryByCode(String code);

}
