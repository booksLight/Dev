package com.boot.edge.service;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.fop.apps.FOPException;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;

public class BarCodeService {

	private static final String SOURCE_DIR="src/main/resources/fop/template/";
	private static final String TARGET_DIR="src/main/resources/fop/report/";
	
	
public void generateReport()  throws IOException, FOPException, TransformerException {
		
		File xsltFile = new File(SOURCE_DIR+"StockStylesheet.xsl");
		StreamSource  xmlSource = new StreamSource(new File(SOURCE_DIR+"Stocks.xml"));	
      
        FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());
        FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
        OutputStream out;
        out = new java.io.FileOutputStream(TARGET_DIR+"/pdf/Stock.pdf");
        
        try {          
            Fop fop = fopFactory.newFop(org.apache.xmlgraphics.util.MimeConstants.MIME_PDF, foUserAgent, out);
            TransformerFactory factory = TransformerFactory.newInstance();            
            Transformer transformer = factory.newTransformer(new StreamSource(xsltFile));           
            Result res = new SAXResult(fop.getDefaultHandler());

            transformer.transform(xmlSource, res);   
            System.out.println("\n Stock report generated successfully...");
        }
        finally {
            out.close();
        }  		
	}

	
	public void convertToFO()  throws IOException, FOPException, TransformerException {
		System.out.println("\n ********* BarCodeService : convertToFO ::START ");
        OutputStream out;       
        File xsltFile = new File(SOURCE_DIR+"StockStylesheet.xsl");
        StreamSource  xmlSource = new StreamSource(new File(SOURCE_DIR+"Stocks.xml"));	
        out = new java.io.FileOutputStream(TARGET_DIR+"Stock.fo");
    
        try {
            // Setup XSLT
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer(new StreamSource(xsltFile));
            Result res = new StreamResult(out);
            transformer.transform(xmlSource, res);
            transformer.transform(xmlSource, res);
        	System.out.println("\n ********* BarCodeService : convertToFO :Stock.fo generated successfully... ");
        } finally {
            out.close();
        }
    	System.out.println("\n ********* BarCodeService : convertToFO ::END ");
    }

}
