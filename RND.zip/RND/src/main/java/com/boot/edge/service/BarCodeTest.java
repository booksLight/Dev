package com.boot.edge.service;

import java.io.IOException;
import javax.xml.transform.TransformerException;

import org.apache.fop.apps.FOPException;

public class BarCodeTest {

	public static void main(String[] args) {

		System.out.println("\n ***** BarCodeTest :: START");
				
		 try {
			 
			 new BarCodeService().generateReport();
			 new BarCodeService().convertToFO();
			 
		 } catch (FOPException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        } catch (IOException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        } catch (TransformerException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
		
		System.out.println("\n ***** BarCodeTest :: END");
	}

}
