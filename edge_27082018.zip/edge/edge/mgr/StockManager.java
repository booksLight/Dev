package com.boot.edge.mgr;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.boot.edge.model.Stock;
import com.boot.edge.model.master.MasterStock;
import com.boot.edge.repo.StockRepository;
import com.boot.edge.repo.master.MasterStockRepository;
import com.boot.edge.service.QrCodeService;
import com.boot.edge.service.ReportService;
import com.boot.edge.ui.StockItemVO;
import com.boot.edge.ui.StockRepoVO;
import com.boot.edge.ui.StockVO;
import com.boot.edge.util.TransformUtil;

import java.io.IOException;
import java.io.OutputStream;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.fop.apps.FOPException;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;

@Component
public class StockManager implements StockApi {

	@Autowired
	private MasterStockRepository mstockRepository;

	@Autowired
	private StockRepository stockRepository;

	@Autowired
	private ReportService reportSvc;
	
	private static final String SOURCE_DIR="/fop/template/";
	private static final String TARGET_DIR="/fop/report/";
	
	@Override
	public void addStock(Stock StockPram) {

		if (StockPram != null) {
			System.out.println("StockRepository invokation : START");
			stockRepository.save(StockPram);
			System.out.println("StockRepository invokation : END");
		} else {
			System.out.println("Stock is null");
		}
		System.out.println("\n Stock added successfully...");
	}

	@Override
	public Stock findStock(Long keyPram) {
		Stock it = null;
		Optional<Stock> Stock = stockRepository.findById(keyPram);
		if (Stock != null & Stock.isPresent()) {
			it = Stock.get();
			System.out.println("Stock found " + it.toString());
			return it;
		} else {
			return it;
		}
	}

	@Override
	public void updateStock(Stock StockPram) {
		if (StockPram != null) {

		}

	}

	@Override
	public void deleteStock(Long keyPram) {
		Stock thisStock = findStock(keyPram);
		if (thisStock != null) {
			stockRepository.delete(thisStock);
			System.out.println("Stock deleted successfully");
		} else {
			System.out.println("Stock  not found");
		}

	}

	@Override
	public List<Stock> stocks() {
		try {
			return stockRepository.findAll();
		} catch (Exception e) {
			System.out.println("\n\t *****  Exception while listing....\n");
			e.printStackTrace();
		}
		return new ArrayList<Stock>();
	}

	// MasterP Stock
	@Override
	public void addMasterStock(StockVO stockVO) {
		if (stockVO != null) {
			mstockRepository.save(transform(stockVO));
			
			
		}
	}

	@Override
	public MasterStock findMasterStock(Long mstockKey) {
		return mstockKey > 0 ? mstockRepository.getOne(mstockKey) : new MasterStock();
	}

	@Override
	public List<MasterStock> mstocks() {
		return mstockRepository.findAll();
	}

	@Override
	public void updateMasterStock(MasterStock mstock) {
		mstockRepository.saveAndFlush(mstock);
		System.out.println("\n*** Master Stock(" + mstock.getId() + ") got an updated...");
	}

	@Override
	public void deleteMasterStock(Long mstockKey) {
		mstockRepository.deleteById(mstockKey);

	}

	@Override
	public Map<Long, String> getStocksMap() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<Long, String> getProductItemStocksMap(Long itemKey) {
		Map<Long, String> mstockMap = null;
		List<MasterStock> mstockype = mstockRepository.findMasterStockByItemCode(itemKey);
		if (mstockype != null) {
			mstockMap = new HashMap<Long, String>();
			for (MasterStock mstock : mstockype) {
				mstockMap.put(mstock.getId(), mstock.getTitle().toString());
			}
		}
		return mstockMap;
	}

	@Override
	public List<StockItemVO> transform(List<MasterStock> mstocks) {
		List<StockItemVO> sivs = new ArrayList<StockItemVO>();
		StockItemVO siv = null;

		if (mstocks != null) {
			for (MasterStock ms : mstocks) {
				siv = new StockItemVO();
				// siv.setProductType(ms.ge);
				// siv.setItemType(findMasterStock(ms.getItemCode()).getTitle());
				siv.setCode(ms.getCode());
				siv.setDate(ms.getDate());
				siv.setTitle(ms.getTitle());
				siv.setRate(ms.getRate());
				siv.setQty(ms.getQty());
				siv.setUom(ms.getUom());
				siv.setValue(ms.getValue());
				siv.setOffer(ms.getOffer());
				siv.setIsActive(ms.getIsActive());
				sivs.add(siv);
			}
		}

		return sivs;
	}

	@Override
	public MasterStock transform(StockVO stockVO) {
		MasterStock mstock = new MasterStock();
		mstock.setCode(stockVO.getCode());
		mstock.setTitle(stockVO.getTitle());
		mstock.setDiscription(stockVO.getDiscription());
		mstock.setOffer(stockVO.getOffer());
		mstock.setQty(stockVO.getQty());
		mstock.setRate(stockVO.getRate());
		mstock.setUom(stockVO.getUom());
		mstock.setValue(mstock.getQty() * mstock.getRate());
		mstock.setIsActive(stockVO.getIsActive());
		mstock.setItemCode(stockVO.getItemCode());
		mstock.setDate(new Timestamp(new Date().getTime()));
		System.out.println("\n Master Stock =" + mstock.toString());
		return mstock;
	}

	@Override
	public List<StockItemVO> getTopItems(List<StockItemVO> sivos) {
		audit(sivos);
		Collections.sort(sivos, StockItemVO.COMPARE_BY_STOCK_DATE);
		System.out.println("\n\t **** Ordered By STOCK DATE ******");
		Collections.reverse(sivos);
		audit(sivos);
		return sivos;
	}

	public void audit(List<StockItemVO> svs) {
		for (StockItemVO sv : svs) {
			System.out.println("\n Product:" + sv.getProductType() + ", Item:" + sv.getItemType() + ", Stock:"
					+ sv.getTitle() + ", QTY:" + sv.getQty());
		}
	}

	@Override
	public Map<String, Integer> stockQtyByDate(List<StockItemVO> sivos) {
		Map<String, Integer> stocksMap = new HashMap<>();
		StockItemVO siv = null;
		for (StockItemVO sv : sivos) {
			String iDate = new SimpleDateFormat("yyyy-MM-dd").format(sv.getDate());
			if (stocksMap.containsKey(iDate)) {
				Integer extv = stocksMap.get(iDate);
				extv += sv.getQty().intValue();
				stocksMap.put(iDate, extv);
			} else {
				stocksMap.put(iDate, sv.getQty().intValue());
			}
		}
		for (String key : stocksMap.keySet()) {
			System.out.println("\n\t Stock Qty by Date[ KEY:" + key + ", QTY:" + stocksMap.get(key) + "]");
		}
		return stocksMap;
	}
	
	
	@Override
	public List<MasterStock> mstocks(String srartDate, String endDate){
		List<MasterStock> stockList = null;
		Timestamp fromtDate = null;
		Timestamp toDate = null;
		
		if(srartDate != null && endDate != null) {	
			fromtDate = TransformUtil.convert2Timestamp(srartDate);		
			toDate = TransformUtil.convert2Timestamp(endDate);
		}
		if(fromtDate != null & toDate != null) {		
			stockList = mstockRepository.mstocks(fromtDate, toDate);
		}
		
		return stockList != null  ? stockList : new ArrayList<MasterStock>();
	}
	
	
	@Override
	public List<StockVO> transformStocks (List<MasterStock> mstocks) {
		List<StockVO> svo =  new ArrayList<StockVO>();
		StockVO sv = null;
		XMLGregorianCalendar cal = null;
		
		if (mstocks != null) {
			System.out.println("\n MASTER STOCKS ==="+mstocks.toString());			
			
			for (MasterStock ms : mstocks) {
				 LocalDateTime ldt = ms.getDate().toLocalDateTime();
				 try {
				 cal = DatatypeFactory.newInstance().newXMLGregorianCalendar();
				 	cal.setYear(ldt.getYear());
			        cal.setMonth(ldt.getMonthValue());
			        cal.setDay(ldt.getDayOfMonth());
				 }catch(Exception e) {e.printStackTrace();}
				 
				sv = new StockVO();
				// siv.setProductType(ms.ge);
				// siv.setItemType(findMasterStock(ms.getItemCode()).getTitle());
				sv.setCode(ms.getCode());
				sv.setDate(ms.getDate().valueOf(ldt));
				sv.setTitle(ms.getTitle());
				sv.setRate(ms.getRate());
				sv.setQty(ms.getQty());
				sv.setUom(ms.getUom());
				sv.setValue(ms.getValue());
				sv.setOffer(ms.getOffer());
				sv.setIsActive(ms.getIsActive());
				svo.add(sv);
			}
		}
		System.out.println("\n STOCKS VALUE OBJ ==="+svo.toString());

		return svo;
	}

	public void generateReport(StockRepoVO svo)   {
		try {
			reportSvc.stockXMLReport(svo);
			reportSvc.stockPDFReport();
			reportSvc.stockFOReport();
		}catch(Exception e) {
			System.out.println("\n StockReport Error :"+e.getMessage());
		}
	}

	
	public void mailOrderAcknowledgment(String custEmail, String custParam, String OrderParam)
			throws AddressException, MessagingException {
		mgrLog(this.getClass(), "mailOrderAcknowledgment", "START");
		if (custEmail != null) {
			String sendto = (custEmail != null ? custEmail : null);
			IMail mail = new MailImpl();

			mail.orderReceipt(sendto, custParam, OrderParam);
			mgrLog(this.getClass(), "mailOrderAcknowledgment", " Order Number  =" + OrderParam);

		} else {
			mgrLog(this.getClass(), "mailOrderAcknowledgment", "Invalid Custoemr emilat");

			mgrLog(this.getClass(), "mailOrderAcknowledgment", "END");
		}
	}
	

}
