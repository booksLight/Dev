package com.boot.edge.ui;

import java.util.List;

import com.boot.edge.model.Product;

public class Voucher {

	private Long productId;
	//List<Product> productType;
	private String productType;
	
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	
}
