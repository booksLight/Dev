package com.boot.edge.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;

@RestController
@RequestMapping("/item")
public class ItemRestController {

	@Autowired
	private ProductApi productApi;
	
	@Autowired
	private ItemApi itemApi;

	
	
	
	
	
	
 
	
	
	//https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram
	
}
