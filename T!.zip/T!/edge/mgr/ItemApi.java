package com.boot.edge.mgr;

import java.util.List;
import java.util.Map;

import com.boot.edge.model.Item;
import com.boot.edge.model.master.MasterItem;

public interface ItemApi {

	public void addMasterItem(MasterItem mItem);
	public MasterItem findMasterItem(Long mItemKey);
	public List<MasterItem> findMasterItemByProdId(Long prodeKey);
	public List<MasterItem> mitems();
	public void updateMasterItem(MasterItem mItem);
	public void deleteMasterItem(Long mItemKey);
	
	public void addItem(Item item);
	public Item findItem(Long key);
	public List<Item> items();
	public void updateItem(Item item);
	public void deleteItem(Long key);
	
	public Map<Long, String> getItemsMap();
	public Map<Long, String> getProductItemsMap(Long productKey);
}
