package com.boot.edge.ui;

import java.sql.Timestamp;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "date", "productCode", "itemCode", "title", "number", "qty", "uom", "rate", "discription",
		"offer", "value", "isActive" })
public class StockVO {

	private String code;
	private Long productCode;
	private Long itemCode;
	private String title;
	private Integer number;
	private Double qty;
	private String uom;
	private Double rate;
	private String discription;
	private Double offer;
	private Double value;
	private String isActive;
	private Timestamp date;
	private String pCode;

	public Long getProductCode() {
		return productCode;
	}

	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}

	public Long getItemCode() {
		return itemCode;
	}

	public void setItemCode(Long itemCode) {
		this.itemCode = itemCode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@XmlAttribute
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Double getQty() {
		return qty;
	}

	public void setQty(Double qty) {
		this.qty = qty;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}

	public String getDiscription() {
		return discription;
	}

	public void setDiscription(String discription) {
		this.discription = discription;
	}

	public Double getOffer() {
		return offer;
	}

	public void setOffer(Double offer) {
		this.offer = offer;
	}

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	public String getpCode() {
		return pCode;
	}

	public void setpCode(String pCode) {
		this.pCode = pCode;
	}

	@Override
	public String toString() {
		return "StockVO [code=" + code + ", productCode=" + productCode + ", itemCode=" + itemCode + ", title=" + title
				+ ", number=" + number + ", qty=" + qty + ", uom=" + uom + ", rate=" + rate + ", discription="
				+ discription + ", offer=" + offer + ", value=" + value + ", isActive=" + isActive + ", date=" + date
				+ ", pCode=" + pCode + "]";
	}

}
