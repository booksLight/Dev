package com.boot.edge.ui;

import java.sql.Timestamp;
import java.util.Date;

public class ProductVO {

	private String title;
	private String code;
	private long stamp = new Date().getTime();
	private String isActive;
	private String comments;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public long getStamp() {
		return new Date().getTime();
	}
	public void setStamp(long stamp) {
		this.stamp = stamp;
	}
	
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "ProductVO [title=" + title + ", code=" + code + ", stamp=" + stamp + ", isActive=" + isActive
				+ ", comments=" + comments + "]";
	}
	
}
