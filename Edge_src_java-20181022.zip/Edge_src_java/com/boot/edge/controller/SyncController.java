package com.boot.edge.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ItemManager;
import com.boot.edge.mgr.ProductApi;
import com.boot.edge.mgr.SyncApi;
import com.boot.edge.mgr.SyncManager;
import com.boot.edge.model.master.MasterItem;
import com.boot.edge.ui.ItemVO;
import com.boot.edge.ui.ProductVO;
import com.boot.edge.ui.StockUI;
import com.boot.edge.ui.StockVO;

@Controller
@RequestMapping("/synch")
public class SyncController {
	private static final Logger logger = LoggerFactory.getLogger(SyncController.class);

	private static final String XSL_FILE = "D://Projects/Source/Template.xlsx";

	@Autowired
	private SyncApi syncMgr;

	@Autowired
	private ItemApi itemApi;

	@Autowired
	private ProductApi prodApi;

	@RequestMapping(value = { "/upload/{type}" }, method = RequestMethod.POST)
	@ResponseBody
	public String loadStock(@PathVariable("type") String uploadKey) {
		List<StockUI> stocks = null;
		String status = "FAILURE";
		try {
			stocks = getStocksDetails();
			status = "SUCCESS";
		} catch (Exception e) {
			status = "FAILURE :" + e.getMessage();
		}
		return status;
	}

	@RequestMapping(value = { "/product" }, method = RequestMethod.GET)
	public String syncProduct() {
		List<ProductVO> products = syncMgr.uploadProduct(XSL_FILE);
		if (products != null && products.size() > 0) {
			syncMgr.synchProduct(products);
		}
		return "redirect:/home";
	}

	@RequestMapping(value = { "/item" }, method = RequestMethod.GET)
	public String syncItem() {
		List<ItemVO> items = syncMgr.uploadItem(XSL_FILE);
		if (items != null && items.size() > 0) {
			syncMgr.synchItem(items);
		}
		return "redirect:/home";
	}

	@RequestMapping(value = { "/stock" }, method = RequestMethod.GET)
	public ModelAndView fetchXlsStock(Model model) {

		ModelAndView mv = new ModelAndView("master/uploadStock");
		try {
			List<StockUI> stocks = getStocksDetails();
			mv.addObject("stocks", stocks);
		} catch (Exception e) {
			System.err.println("\n\t ERROR while get StoksDetails :" + e.getMessage());
			mv.addObject("stocks", new ArrayList<StockUI>());
		}

		return mv;
	}

	@RequestMapping(value = { "/stock/upload" }, method = RequestMethod.POST)
	public String uploadStock() throws IOException, InvalidFormatException {
		syncMgr.synchStock(syncMgr.uploadStock(XSL_FILE));
		return "redirect:/home";
	}

	private List<StockUI> getStocksDetails() throws IOException, InvalidFormatException {
		List<StockUI> stocks = new ArrayList<StockUI>();
		for (StockVO sv : syncMgr.uploadStock(XSL_FILE)) {
			StockUI stock = new StockUI();
			if (sv.getCode() != null)
				stock.setCode(sv.getCode());
			stock.setDate(sv.getDate());
			stock.setTitle(sv.getTitle());
			stock.setQty(sv.getQty());
			stock.setUom(sv.getUom());
			stock.setMrp(sv.getRate());
			stock.setRate(sv.getValue());
			stock.setpCode(sv.getpCode());
			stock.setDiscription(sv.getDiscription());

			if (sv.getCode() != null && sv.getCode().length() > 1) {
				stock.setItemTitle(itemApi.findMasterItemByCode(sv.getpCode()) != null
						? prodApi.findMasterProduct(itemApi.findMasterItemByCode(sv.getpCode()).getProdId()).getTitle()
						: "NA");
				stocks.add(stock);
			}
		}
		return stocks;
	}

}
