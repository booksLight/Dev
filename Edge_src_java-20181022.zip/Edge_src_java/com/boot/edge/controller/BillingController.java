package com.boot.edge.controller;

import java.util.HashMap;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.boot.edge.mgr.InvtApi;
import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;
import com.boot.edge.mgr.StockApi;
import com.boot.edge.model.master.MasterStock;
import com.boot.edge.ui.InvoiceVO;
import com.boot.edge.util.TransformUtil;

@Controller
@RequestMapping("/bill")
public class BillingController {
	private static final Logger logger = LogManager.getLogger(BillingController.class);
	@Autowired
	private ProductApi productApi;
	
	@Autowired
	private ItemApi itemApi;
	
	@Autowired
	private StockApi stockApi;

	@Autowired
	private InvtApi invApi;
	
	
	@GetMapping("/invoice")
	public String loadBillVoucher(Model model) {
		logger.debug(this.getClass()+"loadBillVoucher :START");
		model.addAttribute("products", productApi.getProductsMap());		
		model.addAttribute("items", new HashMap<Long, String>());		
		model.addAttribute("stocks", new HashMap<Long, String>());
		InvoiceVO invo = new InvoiceVO();		
		invo.setInvNo(new TransformUtil().generateInvoiceNumber());
		model.addAttribute("invObj", invo);
		logger.debug(this.getClass()+"loadBillVoucher :END");
		new TransformUtil().getThisWeek();
		return "inventory/invoice";
	}
	
	@PostMapping("/add")
	public String createBillVoucher(@ModelAttribute  InvoiceVO invoiceVO) {
		logger.debug(this.getClass()+"createBillVoucher :START");
		
		logger.debug("\n Bill Details  ="+invoiceVO.toString());
		if(invoiceVO != null) {
		invApi.addInventory(invoiceVO);
		if(invoiceVO.getInvStockCode() != null || invoiceVO.getInvStockCode() >0) {
		MasterStock ms = stockApi.findMasterStock(invoiceVO.getInvStockCode());	
		logger.debug("PRE Master Stock QTY ("+ ms.getQty()+") updating with Soled Stock QTY ("+invoiceVO.getInvQty()+")" );
		ms.setQty(ms.getQty() - invoiceVO.getInvQty());			
		logger.debug("OST Master Stock QTY ("+ ms.getQty()+") updating with Soled Stock QTY ("+invoiceVO.getInvQty()+")" );
		stockApi.updateMasterStock(ms);
		}
		}
		logger.debug(this.getClass()+"createBillVoucher :END");
		return "redirect:/home";
	}
	
	@PostMapping("/create")
	public String createBill() {
		logger.debug(this.getClass()+"createBillVoucher :START");
		
		logger.debug("\n Bill Details  ="+invoiceVO.toString());
		if(invoiceVO != null) {
		invApi.addInventory(invoiceVO);
		if(invoiceVO.getInvStockCode() != null || invoiceVO.getInvStockCode() >0) {
		MasterStock ms = stockApi.findMasterStock(invoiceVO.getInvStockCode());	
		logger.debug("PRE Master Stock QTY ("+ ms.getQty()+") updating with Soled Stock QTY ("+invoiceVO.getInvQty()+")" );
		ms.setQty(ms.getQty() - invoiceVO.getInvQty());			
		logger.debug("OST Master Stock QTY ("+ ms.getQty()+") updating with Soled Stock QTY ("+invoiceVO.getInvQty()+")" );
		stockApi.updateMasterStock(ms);
		}
		}
		logger.debug(this.getClass()+"createBillVoucher :END");
		return "redirect:/home";
	}
	
	
	
	
	
	
}
