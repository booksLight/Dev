package com.boot.edge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.boot.edge.model.Inventory;
import com.boot.edge.mgr.InvtApi;
import com.boot.edge.mgr.ItemApi;

@Controller
@RequestMapping("/vou")
public class VoucherController {

	@Autowired
	private InvtApi invtApi;
	
	@Autowired
	private ItemApi itemApi;

	@RequestMapping(value={"/add"}, method = RequestMethod.GET)
	public ModelAndView loadVoucher() {
		ModelAndView mv = new ModelAndView("voucher");
		return mv;	
	}
	
	@RequestMapping(value={"/list"}, method = RequestMethod.GET)
	public void showInventories() {
		List<Inventory> inventories = invtApi.inventories();
		if (inventories != null) {
		for (Inventory invt : inventories) {
			System.out.println(invt.toString());
		}
		}else {
			System.out.println("Inventory not found.");
		}
	}
	
	@RequestMapping(value={"/add"}, method = RequestMethod.POST)
	public void addInventory() {
		Inventory invtPram = new Inventory();
		invtApi.addInventory(invtPram);		
	}


	


	
	

	//https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram
	
}
