package com.boot.edge.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;


public class BaseAddress {

	 
	 private Long id;
	 private String houseNo;
	 private String streatNo;
	 private String city;
	 private String state;
	 private Number pin;
	 private boolean isActive;
	 private boolean isParmanent;
	 private boolean isLocal;
	 
	  
	public BaseAddress() {
		// TODO Auto-generated constructor stub
	}
	
	
	public BaseAddress(String houseNo, String streatNo, String city, String state, Number pin, boolean isActive,
			boolean isParmanent, boolean isLocal) {
		super();
		this.houseNo = houseNo;
		this.streatNo = streatNo;
		this.city = city;
		this.state = state;
		this.pin = pin;
		this.isActive = isActive;
		this.isParmanent = isParmanent;
		this.isLocal = isLocal;
	}


	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	public String getStreatNo() {
		return streatNo;
	}
	public void setStreatNo(String streatNo) {
		this.streatNo = streatNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Number getPin() {
		return pin;
	}
	public void setPin(Number pin) {
		this.pin = pin;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public boolean isParmanent() {
		return isParmanent;
	}
	public void setParmanent(boolean isParmanent) {
		this.isParmanent = isParmanent;
	}
	public boolean isLocal() {
		return isLocal;
	}
	public void setLocal(boolean isLocal) {
		this.isLocal = isLocal;
	}


	@Override
	public String toString() {
		return "BaseAddress [id=" + id + ", houseNo=" + houseNo + ", streatNo=" + streatNo + ", city=" + city
				+ ", state=" + state + ", pin=" + pin + ", isActive=" + isActive + ", isParmanent=" + isParmanent
				+ ", isLocal=" + isLocal + "]";
	}
	 
	 
}
