package com.boot.edge.controller;

import java.sql.Timestamp;
import java.text.DateFormatSymbols;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.boot.edge.model.master.MasterItem;
import com.boot.edge.model.master.MasterProduct;
import com.boot.edge.model.master.MasterStock;
import com.boot.edge.ui.StockItemVO;
import com.boot.edge.ui.StockVO;
import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;
import com.boot.edge.mgr.StockApi;
import com.boot.edge.util.TransformUtil;
import com.google.gson.Gson;

@Controller
@RequestMapping("/stock")
public class StockController {

	@Autowired
	private ProductApi productApi;
	
	@Autowired
	private ItemApi itemApi;
	
	@Autowired
	private StockApi stockApi;

		
	
	@GetMapping("/list")
	public void listStocks() {
		
	}
	
	@GetMapping("/update")
	public void updateStock() {
		
		
	}
		
	@GetMapping("/delete")
	public void removeStock() {		
		
	}
	
	
	// Master 
	
	@GetMapping("/add")
	public String loadStockVoucher(Model model) {
		Map<Long, String> productMap = null;
		Map<Long, String> itemMap = null;
		List<MasterProduct> mproductType = productApi.masterProducts();
		
		if(mproductType !=null) {
			productMap = new HashMap<>();
			for(MasterProduct mproduct : mproductType) {				
				productMap.put(mproduct.getId(), mproduct.getTitle());
			}
		}		
		model.addAttribute("products", productMap);
		
		List<MasterItem> mitemType = itemApi.mitems();
		if(mitemType !=null) {
			itemMap = new HashMap<>();
			for(MasterItem mitem : mitemType) {
				productMap.put(74l, "-select-");
				itemMap.put(mitem.getId(), mitem.getTitle());
			}
		}
		
		model.addAttribute("items", itemMap);
		model.addAttribute("stock", new StockVO());
		return "master/addStock";
	}

	@PostMapping("/add")
	public String addMasterStockVoucher(@ModelAttribute StockVO stockVO) {
		if(stockVO != null)
		stockApi.addMasterStock(stockVO);		
		return "redirect:/home";
	}	
	
	@GetMapping("/mlist")
	@ResponseBody
	public List<MasterStock> showhMasterStocks() throws Exception {		
		return stockApi.mstocks();		
	}
	
	@GetMapping("/search/{id}")
	@ResponseBody
	public String searchMasterStockById(@PathVariable("id") Long key) throws Exception {
		System.out.println("/n ***** Stock Details ID ="+key);		
		MasterStock mstock =null;	
		mstock = key>0 ?  stockApi.findMasterStock(key) :null;	
		System.out.println("/n ***** Stock Details findMasterStock="+mstock.toString());
		return mstock !=null ? new TransformUtil().object2Json(mstock):null;			
	}
	
	@PostMapping(value = "/list/{id}")
	@ResponseBody
	public Map<Long, String> findMasterStockByItemCode(@PathVariable("id") Long key) throws Exception {
		Map<Long, String> stockMap = stockApi.getProductItemStocksMap(key);			
		System.out.println("\n****** Stock Found :"+stockMap.toString());
		return stockMap;
	}
	
	@SuppressWarnings("deprecation")
	@GetMapping("/stoksinhand")
	@ResponseBody
	public Map<String, Integer> getStocksInHand() throws Exception {	
		Map<String, Integer> stocksMap = new HashMap<>();
		List<MasterStock> mstocks = showhMasterStocks();	
		List<StockItemVO> sivos = stockApi.transform(mstocks);
		stockApi.getTopItems(sivos);
		stockApi.stockQtyByDate(sivos);
        
		if(mstocks !=null) {
			for(MasterStock ms : mstocks) {
				//Month month = Month.from(ms.getDate().toLocalDateTime());				
				stocksMap.put(new TransformUtil().getMonthForInt(ms.getDate().getMonth()), ms.getQty().intValue());
				
			}			
		}
		System.out.println("\n ***** Timestamp Month ="+stocksMap.keySet());
		return stocksMap;
	}
	

	
	@GetMapping("/report")
	@ResponseBody
	public void getStockReportByRange() throws Exception {		
		
		
		
		
		String  srartDate = "2018-07-01";
		String  endDate = "2018-08-23";
		
		
		List<MasterStock> stockRepo = stockApi.mstocks(srartDate, endDate);		
		
		System.out.println("\n\t ***************  Stock Report ******************");
		for(MasterStock ms : stockRepo) {
			System.out.println(ms.toString());
			System.out.println("\n --------------------------------------------------- \n");
		}
		
	}

	
	//https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram
	
}
