package com.boot.edge.service;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.fop.apps.FOPException;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.springframework.stereotype.Service;

import com.boot.edge.ui.StockRepoVO;

@Service
public class ReportService {

	private static final String SOURCE_DIR = "src/main/resources/fop/template/";
	private static final String TARGET_DIR = "src/main/resources/fop/report/";
	private static final String XSL_TEMPLATE = "StockStylesheet.xsl";
	private static final String XML_REPORT = "Stocks.xml";
	private static final String PDF_REPORT = "Stocks.pdf";
	private static final String FO_REPORT = "Stocks.fo";

	 public void stockXMLReport(StockRepoVO svo) {
		 System.out.println("\n ********* ReportService : stockXMLReport ::START ");
			
		        try {
		            JAXBContext context = JAXBContext.newInstance(StockRepoVO.class);
		            Marshaller m = context.createMarshaller();		           
		            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);		           
		           // m.marshal(svo, System.out);
		            m.marshal(svo, new File(TARGET_DIR+XML_REPORT));
		        } catch (JAXBException e) {
		            e.printStackTrace();
		        }
		        System.out.println("\n ********* ReportService : stockXMLReport ::END ");
		    }
	 
	public void stockPDFReport() throws IOException, FOPException, TransformerException {
		System.out.println("\n ********* ReportService : stockReport ::START ");
		File xsltFile = new File(SOURCE_DIR + XSL_TEMPLATE);
		StreamSource xmlSource = new StreamSource(new File(TARGET_DIR + XML_REPORT));
		OutputStream out;

		FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());
		FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
		out = new java.io.FileOutputStream(TARGET_DIR + "/pdf/"+PDF_REPORT);

		try {
			Fop fop = fopFactory.newFop(org.apache.xmlgraphics.util.MimeConstants.MIME_PDF, foUserAgent, out);
			TransformerFactory factory = TransformerFactory.newInstance();
			Transformer transformer = factory.newTransformer(new StreamSource(xsltFile));
			Result res = new SAXResult(fop.getDefaultHandler());

			transformer.transform(xmlSource, res);
			System.out.println("\n Stock report generated successfully...");
		} finally {
			out.close();
		}
		System.out.println("\n ********* ReportService : stockReport ::END ");
	}

	public void stockFOReport() throws IOException, FOPException, TransformerException {
		System.out.println("\n ********* ReportService : stockFoReport ::START ");
		OutputStream out;
		File xsltFile = new File(SOURCE_DIR + XSL_TEMPLATE);
		StreamSource xmlSource = new StreamSource(new File(TARGET_DIR +XML_REPORT));
		out = new java.io.FileOutputStream(TARGET_DIR + FO_REPORT);

		try {
			// Setup XSLT
			TransformerFactory factory = TransformerFactory.newInstance();
			Transformer transformer = factory.newTransformer(new StreamSource(xsltFile));
			Result res = new StreamResult(out);
			transformer.transform(xmlSource, res);
			transformer.transform(xmlSource, res);
		} finally {
			out.close();
		}
		System.out.println("\n ********* ReportService : stockFoReport ::END ");
	}

}
