package com.boot.edge.service;

import javax.mail.*;
import javax.mail.internet.*;
import org.slf4j.*;

public interface IMail {
	
	public void sendMail() throws AddressException, MessagingException;
	public void registrationAcknowledgmet(String sendto, String msg) throws AddressException, MessagingException;
	
	public void orderReceipt(String sendto,  String customerName, String orderNo) throws AddressException, MessagingException;
}
