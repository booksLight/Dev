package com.boot.edge.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.boot.edge.model.Inventory;
import com.boot.edge.model.Item;
import com.boot.edge.model.master.MasterItem;
import com.boot.edge.model.master.MasterProduct;
import com.boot.edge.ui.InventoryVO;
import com.boot.edge.ui.ItemVO;
import com.boot.edge.util.TransformUtil;
import com.boot.edge.mgr.InvtApi;
import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;

@Controller
@RequestMapping("/item")
public class ItemController {

	@Autowired
	private InvtApi invtApi;

	@Autowired
	private ProductApi productApi;

	@Autowired
	private ItemApi itemApi;

	@GetMapping("/add")
	public String loadItemVoucher(Model model) {
		Map<Long, String> productMap = null;
		List<MasterProduct> mproductType = productApi.masterProducts();

		if (mproductType != null) {
			productMap = new HashMap<>();
			for (MasterProduct product : mproductType) {
				productMap.put(product.getId(), product.getTitle());
			}
		}

		model.addAttribute("products", productMap);
		model.addAttribute("item", new ItemVO());
		return "master/addItem";
	}

	@PostMapping("/add")
	public String addItemVoucher(@ModelAttribute ItemVO itemVO) {
		itemApi.addMasterItem(transformItem(itemVO));
		return "redirect:/home";
	}

	private MasterItem transformItem(ItemVO itemVO) {
		System.out.println("\n MasterVO Item = " + itemVO.toString());
		MasterItem mItem = new MasterItem();
		mItem.setCode(itemVO.getCodeUI());
		mItem.setTitle(itemVO.getTitleUI());
		mItem.setDiscription(itemVO.getDiscriptionUI());
		mItem.setDiscount(itemVO.getDiscountUI() != null ? itemVO.getDiscountUI() : 0.0);
		mItem.setProdId(itemVO.getProductId());
		mItem.setProdId(itemVO.getProductId());
		System.out.println("\n Master Item = " + mItem.toString());
		return mItem;
	}

	@GetMapping("/search")
	public void searchItem() {
		Long key = 1l;
		itemApi.findItem(key);
	}

	@GetMapping("/list")
	public List<Item> listItems() {
		List<Item> items = itemApi.items();
		return items != null ? items : new ArrayList<Item>();
	}

	@GetMapping("/update")
	public void updateItem() {

	}

	@GetMapping("/delete")
	public void removeItem() {
		itemApi.updateItem(new Item());
	}

	@PostMapping(value = "/list/{id}")
	@ResponseBody
	public Map<Long, String> findListById(@PathVariable("id") Long key) throws Exception {

		Map<Long, String> itemMap = new HashMap<Long, String>();
		List<MasterItem> mitems = itemApi.findMasterItemByProdId(key);
		if (mitems != null) {
			for (MasterItem mitem : mitems) {
				itemMap.put(mitem.getId(), mitem.getTitle());
			}
		} else {
			System.out.println("Ite not founds.");
		}
		return itemMap;
	}

	@SuppressWarnings("deprecation")
	@GetMapping("/sold")
	@ResponseBody
	public Map<String, Integer> getSoldItems() throws Exception {
		Map<String, Integer> itemSoldMap = new HashMap<>();

		List<InventoryVO> invos = invtApi.transform(invtApi.inventories());
		invos = invtApi.getTopInventories(invos);
		return invtApi.getInventoryQtyByDate(invos);
	}

	@SuppressWarnings("deprecation")
	@GetMapping("/sold/week")
	@ResponseBody
	public Map<String, Integer> geWeeklySales() throws Exception {
		Map<String, Integer> weeklySalesMap = new HashMap<>();
		List<Inventory> invs = invtApi.inventories();
		if (invs != null) {
			for (Inventory inv : invs) {
				Date dt = new Date();
				dt.setTime(inv.getDate().getTime());
				// String formattedDate = new SimpleDateFormat("yyyy-MM-dd").format(dt);
				if (TransformUtil.isThisWeek(dt)) {
					weeklySalesMap.put(TransformUtil.getWeekDay(inv.getDate()), Math.round(inv.getQty().intValue()));
				}

			}

		}
		System.out.println("\n *****Timestamp Dates =" + weeklySalesMap.keySet());
		return weeklySalesMap;
	}

	@GetMapping("/mlist")
	public Map<Integer, String> listMitems() {
		Map<Integer, String> mItemMap = new HashMap<>();
		List<MasterItem> mItems = itemApi.mitems();
		if (mItems != null) {
			for (MasterItem mitem : mItems) {
				mItemMap.put(mitem.getId().intValue(), mitem.getTitle());
			}
		}

		return mItemMap;
	}

	// https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram

}
