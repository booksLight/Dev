package com.boot.edge.util;

import java.io.File;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.text.ParseException;
import com.boot.edge.model.master.MasterProduct;
import com.boot.edge.ui.ProductVO;
import com.boot.edge.ui.StockRepoVO;
import com.boot.edge.ui.StockVO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class TransformUtil {

	public MasterProduct transform(ProductVO productVO, MasterProduct product) {
		MasterProduct mproduct = new MasterProduct();		
		return mproduct;
	}

	public String object2Json(Object obj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return  obj!=null ? objectMapper.writeValueAsString(obj): null;
	}
	
	public static String getMonthForInt(int num) {
        String month = "NA";
        DateFormatSymbols dfs = new DateFormatSymbols();
        String[] months = dfs.getMonths();
      
        if (num >= 0 && num <= 11 ) {
            month = months[num];
        }
        return month;
    }
	public static String getWeekDay(Timestamp stamp) {	    
	    DateFormat format2=new SimpleDateFormat("EE"); 
	    String finalDay=format2.format(stamp);
		 System.out.println("\n ****** getWeekDay ("+stamp+") to a week day ="+finalDay);
        return finalDay;
    }
	
	public String generateInvoiceNumber() {
		Date date = new Date(); // your date
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH);
		int day = cal.get(Calendar.DAY_OF_MONTH);
		int hour = cal.get(Calendar.HOUR);
		int minutes = cal.get(Calendar.MINUTE);
		System.out.println("\n*****Year="+year+",  Month="+month+",  Day="+day+",  Hour="+hour+",  Minutes="+minutes);
		String invNo =""+year+""+(month+1)+""+day+""+hour+""+minutes;
	 return invNo;
	}
	
	public void getThisWeek() {
		
		Map<String, LocalDate> thisWeekMap = new HashMap<String, LocalDate>();
		
		 LocalDate today = LocalDate.now();
		 
		 // Go backward to get Monday
		    LocalDate monday = today;
		    while (monday.getDayOfWeek() != DayOfWeek.MONDAY) {
		      monday = monday.minusDays(1);
		    }
	     
		    // Go forward to get Sunday
		    LocalDate sunday = today;
		    while (sunday.getDayOfWeek() != DayOfWeek.SUNDAY) {
		      sunday = sunday.plusDays(1);
		    }
		    
		    thisWeekMap.put("Today", today);
		    thisWeekMap.put("Nonday", monday);
		    thisWeekMap.put("Sunday", sunday);
		    System.out.println("\n ********************* ");
		    System.out.println("Today: " + today);
		    System.out.println("Monday of the Week: " + monday);
		    System.out.println("Sunday of the Week: " + sunday);
		    toTimestamp(today);
	}
	
	public static Timestamp toTimestamp(LocalDate localDate) {
		 Date date = Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
		 Timestamp timeStamp = new Timestamp(date.getTime());	 		
		 String formattedDate = new SimpleDateFormat("yyyy-MM-dd").format(date.getTime());	 		
		 return timeStamp;
	}
	
	public static boolean isThisWeek(Date datePram) {
		Calendar c = Calendar.getInstance();
		c.setFirstDayOfWeek(Calendar.MONDAY);

		c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);

		Date monday = c.getTime();

		Date nextMonday= new Date(monday.getTime()+7*24*60*60*1000);
		return datePram.after(monday) && datePram.before(nextMonday);
	}
	
	public static Timestamp convert2Timestamp(String str_date ) {
		java.sql.Timestamp timeStampDate = null;
		if(str_date != null) {		
			try {
		      DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		       // you can change format of date
		      Date date = formatter.parse(str_date);
		      timeStampDate = new Timestamp(date.getTime());		      
		      System.out.println("\n\t Converted Timestamp = "+timeStampDate);		     
		    } catch (ParseException e) {
		      System.out.println("Exception :" + e);		      
		    }
		}
		 return timeStampDate;
	}
	
	
}
