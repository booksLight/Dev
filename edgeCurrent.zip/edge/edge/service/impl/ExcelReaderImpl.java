package com.boot.edge.service.impl;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.boot.edge.service.ExcelReader;
import com.boot.edge.ui.StockVO;
import com.boot.edge.util.TransformUtil;

@Service
public class ExcelReaderImpl implements ExcelReader {

	private static final Logger logger = LoggerFactory.getLogger(ExcelReaderImpl.class);

	@Override
	public List<StockVO> readXls(final String xlsFilePath) throws IOException, InvalidFormatException {
		List<StockVO> stockList = new ArrayList<StockVO>();
		// StockVO stockVO = null;
		Integer NO_OF_WROK_BOOKS = 0;
System.out.println("\n ================================== XSLS File Handling : START ==================================================");
		if (xlsFilePath != null) {
			Workbook workbook;
			workbook = openWorkbook(xlsFilePath);
			NO_OF_WROK_BOOKS = workbook.getNumberOfSheets();

			logger.info("\n Number of Sheets found : " + NO_OF_WROK_BOOKS);

			navigateWorkbookSheet(workbook, stockList);
			
			System.out.println("\n Total Scan Records =" + stockList.size());
			System.out.println("\n ================================== XSLS File Handling : END ==================================================");
			return stockList;
		}
		System.out.println("\n ================================== XSLS File Handling : END ==================================================");
		return new ArrayList<StockVO>();
	}
			
			
	private void navigateWorkbookSheet(Workbook workbook, List<StockVO> stockList) throws IOException, InvalidFormatException {
		for (Sheet sheet : workbook) {				
			int c=0;
			if (hasSheetEnpity(sheet)) {
				System.out.println("\n Thi "+sheet.getSheetName()+" is an empty!*");
			}else {
				
				if (sheet.getSheetName().equalsIgnoreCase("Amul")) {
					fetchXlsSheetItems(sheet.getSheetName(),sheet, stockList);						
				}
				
				if (sheet.getSheetName().equalsIgnoreCase("Britannia")) {						
					fetchXlsSheetItems(sheet.getSheetName(),sheet, stockList);					
				}
				
				if (sheet.getSheetName().equalsIgnoreCase("BiskFarm")) {						
					fetchXlsSheetItems(sheet.getSheetName(),sheet, stockList);					
				}
				
				if (sheet.getSheetName().equalsIgnoreCase("Cadbury")) {						
					fetchXlsSheetItems(sheet.getSheetName(),sheet, stockList);					
				}
				
				if (sheet.getSheetName().equalsIgnoreCase("Haldiram")) {						
					fetchXlsSheetItems(sheet.getSheetName(),sheet, stockList);					
				}
				
				/*if (sheet.getSheetName().equalsIgnoreCase("Cadbury")) {						
					fetchXlsSheetItems(sheet.getSheetName(),sheet, stockList);					
				}*/
				
			}
		}
		
	}




	private void fetchXlsSheetItems(String sheetName, Sheet sheet, List<StockVO> stockList) throws IOException, InvalidFormatException {
		if(sheetName != null) {
			int c=0;
			if (sheet.getSheetName().equalsIgnoreCase(sheetName)) {					
				for (Row row1 : sheet) {								
					c++;
					scanXlsItems(row1, sheet, stockList, c);							
					
					if (c == 20) {
						break;							
					}							
				}						
			}	
			}
		}
	
		



	private void scanXlsItems(Row row, Sheet sheet, List<StockVO> stockList, Integer c)  throws IOException, InvalidFormatException {

		StockVO stockVO = new StockVO();							
		
		if (c > 2 && c < 21) {

			for (Cell cell : row) {
				valuesByCellType(cell, stockVO, c);
			}
			if (stockVO.getCode() != null && !stockVO.getCode().isEmpty()) {
				stockList.add(stockVO);
			}
		}
	}

	private void valuesByCellType(Cell cell, StockVO stockVO, Integer counter)
			throws IOException, InvalidFormatException {

		if (cell.getAddress().toString().equalsIgnoreCase("B" + counter)) {
			stockVO.setCode(cell.getRichStringCellValue().getString());
			// System.out.println(cell.getAddress()+":"+cell.getRichStringCellValue());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("C" + counter)) {
			stockVO.setDate(TransformUtil.toTimestamp(LocalDate.now()));
			// System.out.println(cell.getAddress()+":"+TransformUtil.toTimestamp(LocalDate.now()));
		}

		if (cell.getAddress().toString().equalsIgnoreCase("D" + counter)) {
			stockVO.setTitle(cell.getRichStringCellValue().getString());
			// System.out.println(cell.getAddress()+":"+cell.getRichStringCellValue());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("E" + counter)) {
			stockVO.setQty((double) Math.round(cell.getNumericCellValue()));
			// System.out.println(cell.getAddress()+":"+Math.round(cell.getNumericCellValue()));
		}

		if (cell.getAddress().toString().equalsIgnoreCase("F" + counter)) {
			stockVO.setUom(cell.getRichStringCellValue().getString());
			// System.out.println(cell.getAddress()+":"+cell.getRichStringCellValue());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("G" + counter)) {
			stockVO.setRate((double) Math.round(cell.getNumericCellValue()));
			// System.out.println(cell.getAddress()+":"+Math.round(cell.getNumericCellValue()));
		}
		if (cell.getAddress().toString().equalsIgnoreCase("H" + counter)) {
			stockVO.setValue((double) Math.round(cell.getNumericCellValue()));
			// System.out.println(cell.getAddress()+":"+Math.round(cell.getNumericCellValue()));
		}

	}

	private boolean hasSheetEnpity(Sheet sheet) throws IOException, InvalidFormatException {
		return isCellEmpty(sheet.getRow(3).getCell(3));
	}

	public boolean isCellEmpty(final Cell cell) {
		if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
			return true;
		}

		if (cell.getCellType() == Cell.CELL_TYPE_STRING && cell.getStringCellValue().isEmpty()) {
			return true;
		}

		return false;
	}

	private Workbook openWorkbook(final String xlsFilePath) throws IOException, InvalidFormatException {
		Workbook workbook = WorkbookFactory.create(new File(xlsFilePath));
		return workbook;
	}









	@Override
	public List<StockVO> uploadProduct(String xlsFilePath) throws IOException, InvalidFormatException {
		
		List<StockVO> stockList = new ArrayList<StockVO>();
		Integer NO_OF_WROK_BOOKS = 0;
		System.out.println("\n ================================== XSLS File Handling : START ==================================================");
		if (xlsFilePath != null) {
			Workbook workbook = openWorkbook(xlsFilePath);
			NO_OF_WROK_BOOKS = workbook.getNumberOfSheets();
			logger.info("\n Number of Sheets found : " + NO_OF_WROK_BOOKS);

			uploadProductSheet(workbook, stockList);
			
			System.out.println("\n Total Scan Records =" + stockList.size());
			System.out.println("\n ================================== XSLS File Handling : END ==================================================");
			return stockList;
		}
		System.out.println("\n ================================== XSLS File Handling : END ==================================================");
		return new ArrayList<StockVO>();
		
	}


	private void uploadProductSheet(Workbook workbook, List<StockVO> stockList) throws IOException, InvalidFormatException {
		for (Sheet sheet : workbook) {				
			int c=0;
			if (hasSheetEnpity(sheet)) {
				System.out.println("\n Thi "+sheet.getSheetName()+" is an empty!*");
			}else {
				
				if (sheet.getSheetName().equalsIgnoreCase("CONFG")) {
					fetchProducts(sheet.getSheetName(),sheet, stockList);						
				}			
				
			}
		}
		
	}


	private void fetchProducts(String sheetName, Sheet sheet, List<StockVO> stockList) {
		if(sheetName != null) {
			int c=0;
			if (sheet.getSheetName().equalsIgnoreCase(sheetName)) {					
				for (Row row : sheet) {								
					c++;
					scanProducts(row, sheet, stockList, c);							
					
					if (c == 10) {
						break;							
					}							
				}						
			}	
			}
		
	}


	private void scanProducts(Row row, Sheet sheet, List<StockVO> stockList, int c) {
		StockVO stockVO = new StockVO();							
		
		if (c > 2 && c < 10) {

			for (Cell cell : row) {
				readProducts(cell, stockVO, c);
			}
			if (stockVO.getCode() != null && !stockVO.getCode().isEmpty()) {
				stockList.add(stockVO);
			}
		}
		
	}


	private void readProducts(Cell cell, StockVO stockVO, int counter) {


		if (cell.getAddress().toString().equalsIgnoreCase("A" + counter)) {
			//stockVO.setQty((double) Math.round(cell.getNumericCellValue()));
			 System.out.println(cell.getAddress()+":"+Math.round(cell.getNumericCellValue()));
		}


		if (cell.getAddress().toString().equalsIgnoreCase("B" + counter)) {
			//stockVO.setCode(cell.getRichStringCellValue().getString());
			 System.out.println(cell.getAddress()+":"+cell.getRichStringCellValue());
		}

		
		if (cell.getAddress().toString().equalsIgnoreCase("C" + counter)) {
			//stockVO.setUom(cell.getRichStringCellValue().getString());
			 System.out.println(cell.getAddress()+":"+cell.getRichStringCellValue());
		}


	
		
	}

}
