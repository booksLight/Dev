package com.boot.edge.ui;

public class VoucherVO {

}
