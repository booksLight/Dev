package com.boot.edge.mgr;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.boot.edge.model.Product;
import com.boot.edge.model.master.MasterProduct;
import com.boot.edge.repo.ProductRepository;
import com.boot.edge.repo.master.MasterProductRepository;
import com.boot.edge.ui.ProductVO;
import com.boot.edge.util.TransformUtil;

@Component
public class ProductManager implements ProductApi {

	@Autowired
	private MasterProductRepository mProductRepository;

	@Autowired
	private ProductRepository productRepository;

	@Override
	public void addProduct(Product invtPram) {

	}

	@Override
	public Product findProduct(Long key) {
		return productRepository.getOne(key);
	}

	@Override
	public List<Product> products() {
		return productRepository.findAll();
	}

	@Override
	public void updateProduct(Product product) {

	}

	@Override
	public void deleteProduct(Long key) {

	}

	public void addProduct(ProductVO productVO) {
		MasterProduct mproduct = new TransformUtil().transform(productVO, new MasterProduct());
	}

	// MasterProduct
	@Override
	public void addMasterProduct(MasterProduct mProduct) {
		if (mProduct != null) {
			mProductRepository.save(mProduct);
		}
	}

	@Override
	public MasterProduct findMasterProduct(Long mProductKey) {		
		return mProductKey > 0 ? mProductRepository.getOne(mProductKey):null;
	}

	@Override
	public List<MasterProduct> masterProducts() {
		return  mProductRepository.findAll();
	}

	@Override
	public void updateMasterProduct(MasterProduct mproduct) {
		MasterProduct mp = mproduct !=null ? mproduct.getCode() !=null ? findMasterProductByCode(mproduct.getCode()) : null :null;
		if(mp != null) {
			mproduct.setComments("Updated "+mp.getTitle());
			addMasterProduct(synchMasterProduct(mp,mproduct));
			System.out.println("\n **** Successfully updated Product = :"+mproduct.toString());
		}else {
			if(mproduct!=null)				
			addMasterProduct(mproduct);
			System.out.println("\n **** Successfully added Product = :"+mproduct.toString());
		}

	}	

	public MasterProduct findMasterProductByCode(String code) {
		return code != null ? mProductRepository.findMasterProductByCode(code):null;
	}

	@Override
	public void deleteMasterProduct(Long mProductKey) {
		if (mProductKey != null) {
			mProductRepository.delete(findMasterProduct(mProductKey));
		}

	}

	@Override
	public Map<Long, String> getProductsMap() {
		Map<Long, String> productMap = new HashMap<>();
		List<MasterProduct> mproductType = mProductRepository.findAll();
		if(mproductType !=null) {
			productMap = new HashMap<>();
			for(MasterProduct mproduct : mproductType) {
				productMap.put(mproduct.getId(), mproduct.getTitle());
			}
		}		
		return productMap;
	}
	
	private MasterProduct synchMasterProduct(MasterProduct exist, MasterProduct req) {
		
		exist.setCode(req.getCode());		
		exist.setTitle(req.getTitle());	
		exist.setComments(req.getComments());
		exist.setStamp(req.getStamp());
		exist.setIsActive(req.getIsActive());
		
		return exist;
	}

	
}
