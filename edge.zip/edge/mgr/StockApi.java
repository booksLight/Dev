package com.boot.edge.mgr;

import java.util.List;
import java.util.Map;

import com.boot.edge.model.Stock;
import com.boot.edge.model.master.MasterStock;
import com.boot.edge.ui.StockItemVO;
import com.boot.edge.ui.StockVO;

public interface StockApi {

	
	public void addMasterStock(StockVO stockVO);
	//public void addMasterStock(MasterStock mstock);
	public MasterStock findMasterStock(Long mstockKey);
	public List<MasterStock> mstocks();
	public void updateMasterStock(MasterStock mstock);
	public void deleteMasterStock(Long mstockKey);
	
	public void addStock(Stock stock);
	public Stock findStock(Long key);
	public List<Stock> stocks();
	public void updateStock(Stock stock);
	public void deleteStock(Long key);
	
	public Map<Long, String> getStocksMap();
	public Map<Long, String> getProductItemStocksMap(Long itemKey);
	public List<StockItemVO> transform(List<MasterStock> mstocks);
	public MasterStock transform(StockVO stockVO) ;
	public List<StockItemVO> getTopItems(List<StockItemVO> sivos);
	public List<StockItemVO> stockQtyByDate(List<StockItemVO> sivos);
	
}
