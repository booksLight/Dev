package com.boot.edge.mgr;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.boot.edge.model.Inventory;
import com.boot.edge.model.Item;
import com.boot.edge.model.Product;
import com.boot.edge.model.Stock;
import com.boot.edge.model.master.MasterItem;
import com.boot.edge.model.master.MasterProduct;
import com.boot.edge.model.master.MasterStock;
import com.boot.edge.repo.InventoryRepository;
import com.boot.edge.ui.InvoiceVO;


@Component
public class InventoryManager implements InvtApi{

	@Autowired
	private InventoryRepository inventoryRepository;

	@Autowired
	private ProductApi productApi;
	
	@Autowired
	private ItemApi itemApi;
	
	@Autowired
	private StockApi stockApi;

	@Autowired
	private InvtApi invApi;
	
	Inventory invt = null;
	Product prod = null;
	Item item = null;
	Stock stock = null;
		
			
	@Override
	public void addInventory(Inventory invtPram) {		
		if(invt != null) {
			System.out.println("InventoryRepository invokation : START");
			inventoryRepository.save(invt);
			
			
			System.out.println("InventoryRepository invokation : END");
			System.out.println("\n Inventory added successfully...");
		}else {
			System.out.println("Inventory is null");
		}			
	}

	@Override
	public Inventory findInventory(Long key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Inventory> inventories() {
		// TODO Auto-generated method stub
		return inventoryRepository.findAll();
	}

	@Override
	public void updateInventory(Inventory inventory) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteInventory(Long key) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addInventory(InvoiceVO invoiceVO) {
		System.out.println("\n\n\t Invoice VO addInventory ="+invoiceVO.toString());
		Collection<Product> invProducts = null;
		MasterProduct prodRef = null;
		 MasterItem itemRef = null;
		 MasterStock stockRef = null;		
		 
		if(invoiceVO!=null) {			 
			
			/* invProducts = new HashSet<>();
			 prodRef = fetchMasterProduct(invoiceVO.getInvProdCode());
			 itemRef = fetchMasterItem(invoiceVO.getInvItemCode());
			 stockRef = stockApi.findMasterStock(invoiceVO.getInvStockCode());			 
					*/
			invApi.addInventory(initInventory(invoiceVO));
			
			 System.out.println("\n********* Bill got saved .......");
		}
		
	}
	
	private Inventory initInventory(InvoiceVO invoiceVO) {
		System.out.println("\n\n\t Invoice VO initInventory ="+invoiceVO.toString());
		 Double invQty =0.0;
		 invt = new Inventory();
		 invt.setDate(new Timestamp(new Date().getTime()));
		 invt.setNumber(invoiceVO.getInvNo().toString());	
		
		 initProducts(invoiceVO, invt);
		 for(Product prod :invt.getProducts()){
			 for(Item item : prod.getItems()) {
				invQty += item.getQty();
			 }
		 }
		 invt.setQty(invQty);
		 
		 invt.setStatus(true);
		 invt.setValue(invoiceVO.getValue());
		 System.out.println("\n ***\n Inventory Payload ="+invt.toString());
		 return invt;
	}
	
	

	private void initProducts(InvoiceVO invoiceVO, Inventory inventory) {
		System.out.println("\n\n\t Invoice VO initProducts ="+invoiceVO.toString());
		Collection<Product> products = new ArrayList<>();
		 prod = new Product();
		 prod.setInventory(inventory);
		 initItems(invoiceVO, prod);
		 products.add(prod);
		 inventory.setProducts(products);		
	}

	private void initItems(InvoiceVO invoiceVO, Product prod) {
		System.out.println("\n\n\t Invoice VO initItems ="+invoiceVO.toString());
		 Collection<Item> items = new ArrayList<>();
		 Double itmQty = 0.0;	
		 item = new Item();	
		
		 Collection<Stock> stocks =initStocks(invoiceVO,item);
		 item.setStocks(stocks);
		 
		 for(Stock stk : stocks) {
			 itmQty += stk != null ? stk.getQty():0.0;
		 }
		 item.setQty(itmQty);		 
		 items.add(item);
		 prod.setItems(items);		
	}

	private Collection<Stock> initStocks(InvoiceVO invoiceVO, Item item) {
		System.out.println("\n\n\t Invoice VO initStocks ="+invoiceVO.toString());
		 Collection<Stock> stocks = new HashSet<>();
		 stock = new Stock();
		 stock.setQty(invoiceVO.getInvQty());
		 stock.setItem(item);
		 stocks.add(stock);		 
		return stocks;
	}

	private MasterProduct fetchMasterProduct(final Long key) {
	 return key >0 ? productApi.findMasterProduct(key) : new MasterProduct();
	}
	
	private MasterItem fetchMasterItem(final Long key) {
		 return key >0 ? itemApi.findMasterItem(key) : new MasterItem();
	 }
	
	private  List<MasterItem> findMasterItemByProdId(final Long key) {
		 return key >0 ? itemApi.findMasterItemByProdId(key): new ArrayList<MasterItem>();
	}
		
	private MasterStock fetchMasterStock(final Long key) {
		 return key >0 ? stockApi.findMasterStock(key) : new MasterStock();
	 }
}
