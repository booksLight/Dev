package com.boot.edge.ui;

import java.util.Date;

public class InvoiceVO {

	private String invNo;
	private Date invDtd;
	private String invTitle;
	private Long invProdCode;
	private Long invItemCode;
	private Long invStockCode;
	private String invDisc;
	private Double invQty;
	private String invUom;
	private Double invRate;
	private Double value;
	
	public String getInvNo() {
		return invNo;
	}
	public void setInvNo(String invNo) {
		this.invNo = invNo;
	}
	public Date getInvDtd() {
		return invDtd;
	}
	public void setInvDtd(Date invDtd) {
		this.invDtd = invDtd;
	}
	public String getInvTitle() {
		return invTitle;
	}
	public void setInvTitle(String invTitle) {
		this.invTitle = invTitle;
	}
	public Long getInvProdCode() {
		return invProdCode;
	}
	public void setInvProdCode(Long invProdCode) {
		this.invProdCode = invProdCode;
	}
	public Long getInvItemCode() {
		return invItemCode;
	}
	public void setInvItemCode(Long invItemCode) {
		this.invItemCode = invItemCode;
	}
	public Long getInvStockCode() {
		return invStockCode;
	}
	public void setInvStockCode(Long invStockCode) {
		this.invStockCode = invStockCode;
	}
	public String getInvDisc() {
		return invDisc;
	}
	public void setInvDisc(String invDisc) {
		this.invDisc = invDisc;
	}
	public Double getInvQty() {
		return invQty;
	}
	public void setInvQty(Double invQty) {
		this.invQty = invQty;
	}
	public String getInvUom() {
		return invUom;
	}
	public void setInvUom(String invUom) {
		this.invUom = invUom;
	}
	public Double getInvRate() {
		return invRate;
	}
	public void setInvRate(Double invRate) {
		this.invRate = invRate;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}
	@Override
	public String toString() {
		return "InvoiceVO [invNo=" + invNo + ", invDtd=" + invDtd + ", invTitle=" + invTitle + ", invProdCode="
				+ invProdCode + ", invItemCode=" + invItemCode + ", invStockCode=" + invStockCode + ", invDisc="
				+ invDisc + ", invQty=" + invQty + ", invUom=" + invUom + ", invRate=" + invRate + "]";
	}
		
}
