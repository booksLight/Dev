package com.boot.edge.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.boot.edge.model.Item;
import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;

@RestController
@RequestMapping("/item")
public class ItemRestController {

	@Autowired
	private ProductApi productApi;
	
	@Autowired
	private ItemApi itemApi;

	
	
	
	
	
	@PostMapping(value="/listDD/{id}")
	@ResponseBody
	public Map<Long, String>  findListById(@PathVariable("id") Long key) {	
	Map<Long, String> itemMap = new HashMap<Long, String>();
		Item item = itemApi.findItem(key);		
		if(item != null) {	
			itemMap.put(item.getId(), item.getType());
			 System.out.println(" t ****** findListById Item : STRT");		
			System.out.println(item.getId() + " "+item.getNumber()+ " "+item.getQty()+ " "+item.getStocks().toString());		
			item.setStocks(null);
					
		}else {
			System.out.println("Ite not founds.");
		}
		return itemMap;
	}
	
 
	
	
	//https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram
	
}
