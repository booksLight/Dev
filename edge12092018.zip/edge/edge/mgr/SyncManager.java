package com.boot.edge.mgr;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.boot.edge.controller.SyncController;
import com.boot.edge.service.ExcelReader;
import com.boot.edge.ui.ItemVO;
import com.boot.edge.ui.ProductVO;
import com.boot.edge.ui.StockVO;

@Component
public class SyncManager implements SyncApi{
	
	private static final Logger logger = LoggerFactory.getLogger(SyncManager.class);

	@Autowired
	private ExcelReader excelReader;

	@Override
	public List<ProductVO> uploadProduct(String xlsFilePath) throws IOException, InvalidFormatException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<StockVO> uploadStock(String xlsFilePath) throws IOException, InvalidFormatException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ItemVO> uploadItem(String xlsFilePath) throws IOException, InvalidFormatException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Workbook openWorkbook(String xlsFilePath) throws IOException, InvalidFormatException {
		logger.info("It's in SyncManager.openWorkbook : START");
		if(xlsFilePath != null)
		return WorkbookFactory.create(new File(xlsFilePath));
		return null;		
	}

	@Override
	public Sheet navigateWorkbookSheets(String sheetName, Workbook workbook) throws IOException, InvalidFormatException {
		logger.info("It's in SyncManager.navigateWorkbookSheets : START");
		if (sheetName != null && workbook != null) {
			for (Sheet sheet : workbook) {				
				if( sheet.getSheetName().equalsIgnoreCase(sheetName)) {					
					return sheet;
				}				
			}			
		}		
		logger.info("It's in SyncManager.navigateWorkbookSheets : END");
		return null;
	}

	@Override
	public List<ItemVO> scanItems(Sheet sheet) throws IOException, InvalidFormatException {
		logger.info("It's in SyncManager.scanItems : START");
		ItemVO itemVO = null;
		 List<ItemVO> items = new ArrayList<ItemVO>();	
		if (sheet != null) {			
			int counter=16;
			for (Row row : sheet) {	
				if (row.getRowNum() >15 && row.getRowNum() < 25) {					
					counter++;
					itemVO = new ItemVO();
					
					for (Cell cell : row) {	
						
						if (cell.getColumnIndex() >=0  && cell.getColumnIndex() < 3) {							
							valuesByCellType(cell,itemVO, counter);							
						}
					}				
					
					
					if (itemVO.getCodeUI() != null && !itemVO.getCodeUI().isEmpty()) {
						items.add(itemVO);
					}
				}
			
				
			}
		}
		logger.info("It's in SyncManager.scanItems : END");
		return items;
	}
	
	
	
	private void valuesByCellType(Cell cell, ItemVO itemVO, int counter) throws IOException, InvalidFormatException {
		
			if (cell.getAddress().toString().equalsIgnoreCase("A" + counter)) {
				itemVO.setProductType(cell.getRichStringCellValue().getString());
			}

			if (cell.getAddress().toString().equalsIgnoreCase("B" + counter)) {					
					itemVO.setDiscriptionUI(cell.getRichStringCellValue().getString());
			}

			if (cell.getAddress().toString().equalsIgnoreCase("C" + counter)) {
				itemVO.setCodeUI(cell.getRichStringCellValue().getString());
			}
			
	}

	
	private boolean isEnpty(Sheet sheet) throws IOException, InvalidFormatException {
		return isCellEmpty(sheet.getRow(3).getCell(3));
	}
	
	private boolean isCellEmpty(final Cell cell) {
		if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
			return true;
		}
		if (cell.getCellType() == Cell.CELL_TYPE_STRING && cell.getStringCellValue().isEmpty()) {
			return true;
		}
		return false;
	}
		
}
