package com.boot.edge.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.boot.edge.mgr.SyncManager;
import com.boot.edge.ui.ItemVO;

import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

@Controller
@RequestMapping("/synch")
public class SyncController {
	private static final Logger logger = LoggerFactory.getLogger(SyncController.class);

	private static final String XSL_FILE = "D://Projects/Source/Template.xlsx";

	@Autowired
	private SyncManager syncMgr;

	@RequestMapping(value = { "/item" }, method = RequestMethod.GET)
	public void syncItem() { 
		logger.info("It's in SyncController.syncItem : START");
		try {
			Workbook workbook = syncMgr.openWorkbook(XSL_FILE);
			logger.info("Total Sheets in workbook :"+ workbook != null ? ""+workbook.getNumberOfSheets() : "workbook not found");
			Sheet configSheet = syncMgr.navigateWorkbookSheets("CONFG", workbook);
			logger.info("Sheet name is :"+ configSheet != null ? ""+configSheet.getSheetName() : "configSheet not found");
			List<ItemVO> scanItems = syncMgr.scanItems(configSheet);
			System.out.println("\n\t Total "+scanItems.size()+" scaned \n \t Iterating items \n");
			for(ItemVO vo : scanItems)
				System.out.println("\n"+vo.toString());
			
		}catch(Exception e) {
			System.out.println("Item Synchronization error :"+e.getMessage());
		}
		logger.info("It's in SyncController.syncItem : START");
	}
}
