package com.boot.edge.ui;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;


public class InventoryVO {
	
	private Long id;	
	private Timestamp date;
	private String number;
	private Double qty;
	private Double value;	
	private boolean status;
	
	
	private Collection<ProductVO> productVos = new HashSet<>();

	
	public InventoryVO() {
	}

	public InventoryVO(Timestamp date, String number, Double qty, Double value, boolean status,
			Collection<ProductVO> productVos) {
		super();
		this.date = date;
		this.number = number;
		this.qty = qty;
		this.value = value;
		this.status = status;
		this.productVos = productVos;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public Double getQty() {
		return qty;
	}

	public void setQty(Double qty) {
		this.qty = qty;
	}

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Collection<ProductVO> getProductVos() {
		return productVos;
	}

	public void setProductVos(Collection<ProductVO> productVos) {
		this.productVos = productVos;
	}
	
	public static Comparator<InventoryVO> COMPARE_BY_STOCK_DATE = new Comparator<InventoryVO>() {
        public int compare(InventoryVO one, InventoryVO other) {
            return one.date.compareTo(other.date);
        }
    };
}
