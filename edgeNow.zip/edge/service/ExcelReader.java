package com.boot.edge.service;

import java.io.IOException;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.boot.edge.ui.StockVO;

public interface ExcelReader {

	public List<StockVO> readXls(String xlsFilePath) throws IOException, InvalidFormatException;

	public List<StockVO> configProduct(String xlsFilePath) throws IOException, InvalidFormatException ;

	public List<StockVO> configProductItems(String xlsFilePath) throws IOException, InvalidFormatException;
	
}
