package com.boot.edge.mgr;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.boot.edge.service.ExcelReader;
import com.boot.edge.ui.ItemVO;
import com.boot.edge.ui.ProductVO;
import com.boot.edge.ui.StockVO;
import com.boot.edge.util.TransformUtil;

@Component
public class SyncManager implements SyncApi {

	private static final Logger logger = LoggerFactory.getLogger(SyncManager.class);

	@Autowired
	private ExcelReader excelReader;

	Workbook workbook = null;
	Sheet configSheet = null;

	@Override
	public List<StockVO> uploadStock(String xlsFilePath) throws IOException, InvalidFormatException {
		
			workbook = openWorkbook(xlsFilePath);
			List<StockVO> stocks = navigateWorkbookSheet(workbook);
			System.out.println("\t Total " + stocks.size() + " stocks Scaned ");
			int c=0;
			for(StockVO sv : stocks) {
				c++;
				System.out.println(c+ "). "+sv.toString());
			}
			return stocks;
		
	}

	private List<StockVO> navigateWorkbookSheet(Workbook workbook) throws IOException, InvalidFormatException {
		List<StockVO> stockList = new ArrayList<StockVO>();
		if (workbook != null)
			for (Sheet sheet : workbook) {
				int c = 0;
				if (hasSheetEnpity(sheet)) {
					System.out.println("\n Thi " + sheet.getSheetName() + " is an empty!*");
				} else {

					if (sheet.getSheetName().equalsIgnoreCase("Amul")) {
						fetchXlsSheetItems(sheet.getSheetName(), sheet, stockList);
					}

					if (sheet.getSheetName().equalsIgnoreCase("Britannia")) {
						fetchXlsSheetItems(sheet.getSheetName(), sheet, stockList);
					}

					if (sheet.getSheetName().equalsIgnoreCase("BiskFarm")) {
						fetchXlsSheetItems(sheet.getSheetName(), sheet, stockList);
					}

					if (sheet.getSheetName().equalsIgnoreCase("Cadbury")) {
						fetchXlsSheetItems(sheet.getSheetName(), sheet, stockList);
					}

					if (sheet.getSheetName().equalsIgnoreCase("Haldiram")) {
						fetchXlsSheetItems(sheet.getSheetName(), sheet, stockList);
					}
				}
			}
		return stockList;
	}

	private void fetchXlsSheetItems(String sheetName, Sheet sheet, List<StockVO> stockList)
			throws IOException, InvalidFormatException {
		if (sheetName != null) {
			int c = 0;
			if (sheet.getSheetName().equalsIgnoreCase(sheetName)) {
				for (Row row1 : sheet) {
					c++;
					scanXlsItems(row1, sheet, stockList, c);

					if (c == 20) {
						break;
					}
				}
			}
		}
	}

	private void scanXlsItems(Row row, Sheet sheet, List<StockVO> stockList, Integer c)
			throws IOException, InvalidFormatException {

		StockVO stockVO = new StockVO();

		if (c > 2 && c < 21) {

			for (Cell cell : row) {
				valuesByCellType(cell, stockVO, c);
			}
			if (stockVO.getCode() != null && !stockVO.getCode().isEmpty()) {
				stockList.add(stockVO);
			}
		}
	}

	private void valuesByCellType(Cell cell, StockVO stockVO, Integer counter)
			throws IOException, InvalidFormatException {

		if (cell.getAddress().toString().equalsIgnoreCase("B" + counter)) {
			stockVO.setCode(cell.getRichStringCellValue().getString());
			// System.out.println(cell.getAddress()+":"+cell.getRichStringCellValue());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("C" + counter)) {
			stockVO.setDate(TransformUtil.toTimestamp(LocalDate.now()));
			// System.out.println(cell.getAddress()+":"+TransformUtil.toTimestamp(LocalDate.now()));
		}

		if (cell.getAddress().toString().equalsIgnoreCase("D" + counter)) {
			stockVO.setTitle(cell.getRichStringCellValue().getString());
			// System.out.println(cell.getAddress()+":"+cell.getRichStringCellValue());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("E" + counter)) {
			stockVO.setQty((double) Math.round(cell.getNumericCellValue()));
			// System.out.println(cell.getAddress()+":"+Math.round(cell.getNumericCellValue()));
		}

		if (cell.getAddress().toString().equalsIgnoreCase("F" + counter)) {
			stockVO.setUom(cell.getRichStringCellValue().getString());
			// System.out.println(cell.getAddress()+":"+cell.getRichStringCellValue());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("G" + counter)) {
			stockVO.setRate((double) Math.round(cell.getNumericCellValue()));
			// System.out.println(cell.getAddress()+":"+Math.round(cell.getNumericCellValue()));
		}
		if (cell.getAddress().toString().equalsIgnoreCase("H" + counter)) {
			stockVO.setValue((double) Math.round(cell.getNumericCellValue()));
			// System.out.println(cell.getAddress()+":"+Math.round(cell.getNumericCellValue()));
		}

	}

	/*
	 * Configure /Uploading Products
	 * 
	 * @see com.boot.edge.mgr.SyncApi#uploadProduct(java.lang.String)
	 */
	@Override
	public List<ProductVO> uploadProduct(String xlsFilePath) {
		try {
			workbook = openWorkbook(xlsFilePath);
			configSheet = workbook != null ? navigateWorkbookSheets("CONFG", workbook) : null;
			List<ProductVO> scanProducts = scanProducts(configSheet);
			System.out.println("\t Total " + scanProducts.size() + " products Scaned ");
			return scanProducts;

		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@Override
	public List<ItemVO> uploadItem(String xlsFilePath) {
		List<ItemVO> scanItems = null;
		try {
			workbook = openWorkbook(xlsFilePath);
			configSheet = workbook != null ? navigateWorkbookSheets("CONFG", workbook) : null;
			scanItems = configSheet != null ? scanItems(configSheet) : null;
			System.out.println("\t Total " + scanItems.size() + " Products Items scaned ");
			return scanItems;
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@Override
	public Workbook openWorkbook(String xlsFilePath) throws IOException, InvalidFormatException {

		if (xlsFilePath != null)
			return WorkbookFactory.create(new File(xlsFilePath));
		return null;
	}

	@Override
	public Sheet navigateWorkbookSheets(String sheetName, Workbook workbook)
			throws IOException, InvalidFormatException {

		if (sheetName != null && workbook != null) {
			for (Sheet sheet : workbook) {
				if (sheet.getSheetName().equalsIgnoreCase(sheetName)) {
					return sheet;
				}
			}
		}

		return null;
	}

	/*
	 * Scanning Product from Sheet
	 * 
	 * @see
	 * com.boot.edge.mgr.SyncApi#scanProducts(org.apache.poi.ss.usermodel.Sheet)
	 */
	public List<ProductVO> scanProducts(Sheet sheet) throws IOException, InvalidFormatException {
		ProductVO productVO = null;
		List<ProductVO> products = new ArrayList<ProductVO>();
		if (sheet != null) {
			int counter = 2;
			for (Row row : sheet) {
				if (row.getRowNum() > 1 && row.getRowNum() < 12) {
					counter++;
					productVO = new ProductVO();

					for (Cell cell : row) {

						if (cell.getColumnIndex() >= 0 && cell.getColumnIndex() < 5) {
							productsByCells(cell, productVO, counter);
						}
					}

					if (productVO.getCode() != null && !productVO.getCode().isEmpty()) {
						products.add(productVO);
					}
				}

			}
		}
		return products;
	}

	// Author@Rakesh
	private void productsByCells(Cell cell, ProductVO productVO, int counter) {

		if (cell.getAddress().toString().equalsIgnoreCase("A" + counter)) {
			productVO.setComments("" + Math.round(cell.getNumericCellValue()));

		}

		if (cell.getAddress().toString().equalsIgnoreCase("B" + counter)) {
			productVO.setTitle(cell.getRichStringCellValue().toString());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("C" + counter)) {
			productVO.setCode(cell.getRichStringCellValue().toString());
		}

	}

	/*
	 * Scanning Product Items from Sheet
	 * 
	 * @see com.boot.edge.mgr.SyncApi#scanItems(org.apache.poi.ss.usermodel.Sheet)
	 */
	@Override
	public List<ItemVO> scanItems(Sheet sheet) throws IOException, InvalidFormatException {

		List<ItemVO> items = new ArrayList<ItemVO>();

		if (sheet != null) {

			scanAmulItems(sheet, items);
			scanBritannialItems(sheet, items);
			scanBiskFarmItems(sheet, items);
			scanCadburyItems(sheet, items);
			scanHaldiramItems(sheet, items);
		}

		return items;
	}

	// Author@Rakesh
	private void scanHaldiramItems(Sheet sheet, List<ItemVO> items) {

		int counter = 16;
		for (Row row : sheet) {
			if (row.getRowNum() > 15 && row.getRowNum() < 30) {
				counter++;
				ItemVO itemVO = new ItemVO();
				for (Cell cell : row) {
					if (cell.getColumnIndex() >= 16 && cell.getColumnIndex() < 19) {
						scanHaldiramItems(cell, itemVO, counter);
					}
				}
				if (itemVO.getCodeUI() != null && !itemVO.getCodeUI().isEmpty()) {
					items.add(itemVO);
				}
			}
		}

	}

	// Author@Rakesh
	private void scanCadburyItems(Sheet sheet, List<ItemVO> items) {

		int counter = 16;
		for (Row row : sheet) {
			if (row.getRowNum() > 15 && row.getRowNum() < 30) {
				counter++;
				ItemVO itemVO = new ItemVO();
				for (Cell cell : row) {
					if (cell.getColumnIndex() >= 12 && cell.getColumnIndex() < 15) {
						scanCadburyItems(cell, itemVO, counter);
					}
				}
				if (itemVO.getCodeUI() != null && !itemVO.getCodeUI().isEmpty()) {
					items.add(itemVO);
				}
			}
		}
	}

	// Author@Rakesh
	private void scanBiskFarmItems(Sheet sheet, List<ItemVO> items) {

		int counter = 16;
		for (Row row : sheet) {
			if (row.getRowNum() > 15 && row.getRowNum() < 30) {
				counter++;
				ItemVO itemVO = new ItemVO();
				for (Cell cell : row) {
					if (cell.getColumnIndex() >= 8 && cell.getColumnIndex() < 11) {
						scanBiskFarmItems(cell, itemVO, counter);
					}
				}
				if (itemVO.getCodeUI() != null && !itemVO.getCodeUI().isEmpty()) {
					items.add(itemVO);
				}
			}
		}

	}

	// Author@Rakesh
	private void scanBritannialItems(Sheet sheet, List<ItemVO> items) {
		int counter = 16;
		for (Row row : sheet) {
			if (row.getRowNum() > 15 && row.getRowNum() < 30) {
				counter++;
				ItemVO itemVO = new ItemVO();
				for (Cell cell : row) {
					if (cell.getColumnIndex() >= 4 && cell.getColumnIndex() < 7) {
						scanBritannialItems(cell, itemVO, counter);
					}
				}
				if (itemVO.getCodeUI() != null && !itemVO.getCodeUI().isEmpty()) {
					items.add(itemVO);
				}
			}
		}
	}

	// Author@Rakesh
	private void scanAmulItems(Sheet sheet, List<ItemVO> items) throws IOException, InvalidFormatException {
		int counter = 16;
		for (Row row : sheet) {
			if (row.getRowNum() > 15 && row.getRowNum() < 30) {
				counter++;
				ItemVO itemVO = new ItemVO();
				for (Cell cell : row) {
					if (cell.getColumnIndex() >= 0 && cell.getColumnIndex() < 3) {
						scanAmulItems(cell, itemVO, counter);
					}
				}
				if (itemVO.getCodeUI() != null && !itemVO.getCodeUI().isEmpty()) {
					items.add(itemVO);
				}
			}
		}
	}

	// Scanned
	private void scanHaldiramItems(Cell cell, ItemVO itemVO, int counter) {

		if (cell.getAddress().toString().equalsIgnoreCase("Q" + counter)) {
			itemVO.setProductType(cell.getRichStringCellValue().getString());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("R" + counter)) {
			itemVO.setDiscriptionUI(cell.getRichStringCellValue().getString());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("S" + counter)) {
			itemVO.setCodeUI(cell.getRichStringCellValue().getString());
		}

	}

	// Scanned
	private void scanCadburyItems(Cell cell, ItemVO itemVO, int counter) {
		if (cell.getAddress().toString().equalsIgnoreCase("M" + counter)) {
			itemVO.setProductType(cell.getRichStringCellValue().getString());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("N" + counter)) {
			itemVO.setDiscriptionUI(cell.getRichStringCellValue().getString());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("O" + counter)) {
			itemVO.setCodeUI(cell.getRichStringCellValue().getString());
		}
	}

	// Scanned
	private void scanBiskFarmItems(Cell cell, ItemVO itemVO, int counter) {
		if (cell.getAddress().toString().equalsIgnoreCase("I" + counter)) {
			itemVO.setProductType(cell.getRichStringCellValue().getString());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("J" + counter)) {
			itemVO.setDiscriptionUI(cell.getRichStringCellValue().getString());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("K" + counter)) {
			itemVO.setCodeUI(cell.getRichStringCellValue().getString());
		}
	}

	// Scanned
	private void scanBritannialItems(Cell cell, ItemVO itemVO, int counter) {

		if (cell.getAddress().toString().equalsIgnoreCase("E" + counter)) {
			itemVO.setProductType(cell.getRichStringCellValue().getString());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("F" + counter)) {
			itemVO.setDiscriptionUI(cell.getRichStringCellValue().getString());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("G" + counter)) {
			itemVO.setCodeUI(cell.getRichStringCellValue().getString());
		}
	}

	// Scanned
	private void scanAmulItems(Cell cell, ItemVO itemVO, int counter) {

		if (cell.getAddress().toString().equalsIgnoreCase("A" + counter)) {
			itemVO.setProductType(cell.getRichStringCellValue().getString());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("B" + counter)) {
			itemVO.setDiscriptionUI(cell.getRichStringCellValue().getString());
		}

		if (cell.getAddress().toString().equalsIgnoreCase("C" + counter)) {
			itemVO.setCodeUI(cell.getRichStringCellValue().getString());
		}

	}

	private boolean isEnpty(Sheet sheet) throws IOException, InvalidFormatException {
		return isCellEmpty(sheet.getRow(3).getCell(3));
	}

	private boolean isCellEmpty(final Cell cell) {
		if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
			return true;
		}
		if (cell.getCellType() == Cell.CELL_TYPE_STRING && cell.getStringCellValue().isEmpty()) {
			return true;
		}
		return false;
	}

	private boolean hasSheetEnpity(Sheet sheet) throws IOException, InvalidFormatException {
		return isCellEmpty(sheet.getRow(3).getCell(3));
	}

}
