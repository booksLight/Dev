package com.boot.edge.mgr;

import java.io.IOException;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.boot.edge.ui.ItemVO;
import com.boot.edge.ui.ProductVO;
import com.boot.edge.ui.StockVO;

public interface SyncApi {
	public Workbook openWorkbook(String xlsFilePath) throws IOException, InvalidFormatException;
	public Sheet navigateWorkbookSheets(String sheetName, Workbook workbook) throws IOException, InvalidFormatException; 
	public List<ItemVO> scanItems(Sheet sheet) throws IOException, InvalidFormatException; 
	
	public List<ProductVO> uploadProduct(String xlsFilePath);
	public List<StockVO> uploadStock(String xlsFilePath) throws IOException, InvalidFormatException;
	public List<ItemVO> uploadItem(String xlsFilePath);
	
}
