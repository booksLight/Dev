package com.boot.edge.repo.master;

import java.util.List;
import java.sql.Timestamp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.boot.edge.model.master.MasterStock;

@Repository
public interface MasterStockRepository extends JpaRepository<MasterStock, Long>{

	MasterStock findMasterStockByCode(String code);
	List<MasterStock> findMasterStockByItemCode(Long itemCodeKey);
	@Query("select ms from MasterStock ms where ms.date > ?1 and ms.date < ?2")
	List<MasterStock> mstocks(Timestamp srartDate, Timestamp endDate);
}
