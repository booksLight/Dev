package com.boot.edge.mgr;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.boot.edge.model.Stock;
import com.boot.edge.model.master.MasterStock;
import com.boot.edge.repo.StockRepository;
import com.boot.edge.repo.master.MasterStockRepository;

@Component
public class StockManager implements StockApi {

	@Autowired
	private MasterStockRepository mstockRepository;
	
	@Autowired
	private StockRepository stockRepository;
	
	@Override
	public void addStock(Stock StockPram) {
		
		if(StockPram != null) {
			System.out.println("StockRepository invokation : START");
			stockRepository.save(StockPram);
			System.out.println("StockRepository invokation : END");
		}else {
			System.out.println("Stock is null");
		}		
		System.out.println("\n Stock added successfully...");		
	}

	@Override
	public Stock findStock(Long keyPram) {
		Stock it = null;
		Optional<Stock> Stock = stockRepository.findById(keyPram);
		if(Stock != null & Stock.isPresent() ) {
			it = Stock.get();			
			System.out.println("Stock found "+it.toString());
			return it;
		}else {
			return it;
		}	
	}
	

	@Override
	public void updateStock(Stock StockPram) {
		if(StockPram != null) {
			
		}

	}
	

	@Override
	public void deleteStock(Long keyPram) {
		Stock thisStock = findStock(keyPram);
		if(thisStock != null ) {
			stockRepository.delete(thisStock);
			System.out.println("Stock deleted successfully");
		}else {
			System.out.println("Stock  not found");
		}		

	}

	@Override
	public  List<Stock> stocks() {
		try{
			return stockRepository.findAll();
		}catch(Exception e) {
			System.out.println("\n\t *****  Exception while listing....\n");
			e.printStackTrace();
		}
		return new ArrayList<Stock>();
	}

	
	
	//MasterP Stock
	@Override
	public void addMasterStock(MasterStock mstock) {		
		if(mstock!=null) {
			mstockRepository.save(mstock);
		}		
	}

	@Override
	public MasterStock findMasterStock(Long mstockKey) {		
		return mstockKey>0 ? mstockRepository.getOne(mstockKey) : new MasterStock();
	}

	@Override
	public List<MasterStock> mstocks() {
		return mstockRepository.findAll();
	}

	@Override
	public void updateMasterStock(MasterStock mstock) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteMasterStock(Long mstockKey) {
		mstockRepository.deleteById(mstockKey);
		
	}

	@Override
	public Map<Long, String> getStocksMap() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<Long, String> getProductItemStocksMap(Long itemKey) {
		 Map<Long, String> mstockMap = null;
		List<MasterStock> mstockype = mstockRepository.findMasterStockByItemCode(itemKey);
		if(mstockype !=null) {
			mstockMap = new HashMap<>();
			for(MasterStock mstock : mstockype) {
				mstockMap.put(mstock.getId(), mstock.getTitle());
			}
		}		
		return mstockMap;
	}
	
	/*private Stock compareUpdat(Stock currentStock, Stock StockPram) {
		//currentStock.setId(StockPram.getId());
		currentStock.setNumber(StockPram.getNumber());
		currentStock.setQty(StockPram.getQty());
		currentStock.setType(StockPram.getType());
		currentStock.setDiscount(StockPram.getDiscount());
		
		Collection<Stock> currentstocks =  currentStock.getStocks();
		Collection<Stock> pramstocks =  StockPram.getStocks();
		
		for(Stock cStock : currentstocks) {
			for(Stock pStock : pramstocks) {
				if(cStock.getId().equals(pStock.getId())) {
					doUpdateStock(cStock, pStock);
				}
			}
			System.out.println("\nSTOCK STATUS ="+cStock.toString());
		}
		
		return null;
	}

	private void doUpdateStock(Stock cStock, Stock pStock) {
		cStock.setNumber(pStock.getNumber());
		cStock.setRate(pStock.getRate());
		cStock.setType(pStock.getType());
		cStock.setUom(pStock.getUom());
		cStock.setDiscription(pStock.getDiscription());		
	}*/

}
