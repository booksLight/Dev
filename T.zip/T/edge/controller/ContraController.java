package com.boot.edge.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.boot.edge.model.Item;
import com.boot.edge.model.Product;
import com.boot.edge.model.Stock;
import com.boot.edge.ui.StockVO;
import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;
import com.boot.edge.mgr.StockApi;
import com.boot.edge.util.ItemUtil;

@Controller
@RequestMapping("/contra")
public class ContraController {

	@Autowired
	private ProductApi productApi;
	
	@Autowired
	private ItemApi itemApi;
	
	@Autowired
	private StockApi stockApi;

	@GetMapping("/add")
	public String loadStockVoucher(Model model) {
				
		model.addAttribute("products", productApi.getProductsMap());		
		
		model.addAttribute("items", new HashMap<Long, String>());		
		model.addAttribute("stocks", new HashMap<Long, String>());		
		model.addAttribute("stock", new StockVO());
		return "contraVoucher";
	}
	
	@PostMapping("/add")
	public String addItemVoucher(@ModelAttribute Item item) {
		//itemApi.addItem(new Item());
		
		System.out.println("\n **** addItemVoucher :"+item.toString());
		return "/home";
	}
	
	@GetMapping("/search")
	public void searchItem() {
		Long key=1l;
		itemApi.findItem(key);	
	}
	
	@GetMapping("/list")
	public void listItems() {
		List<Item> items = itemApi.items();
		if(items != null) {
			 System.out.println("\t ****** Listing Items : STRT");
		for(Item it :items) {
			System.out.println(it.getId() + " "+it.getNumber()+ " "+it.getQty()+ " "+it.getStocks().toString());
		}
		 System.out.println("\t ****** Listing Items : END");
		}else {
			System.out.println("Item not founds.");
		}
	}
	
	@GetMapping("/update")
	public void updateItem() {
		Item itm = new ItemUtil().initItem();
		itm.setId(1l);
		itm.setNumber(itm.getNumber()+10);
		itm.setDiscription(itm.getDiscription()+" Updated one..");
		itemApi.updateItem(itm);
		System.out.println("Item "+itm.getId() +" updated successfully.");
		
	}
		
	@GetMapping("/delete")
	public void removeItem() {		
		itemApi.updateItem(new Item());
	}
	
	
	
	//https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram
	
}
