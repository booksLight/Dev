package com.boot.edge.repo.master;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.edge.model.master.MasterProduct;

public interface MasterProductRepository extends JpaRepository<MasterProduct, Long> {
	MasterProduct findMasterProductByCode(String code);
}
