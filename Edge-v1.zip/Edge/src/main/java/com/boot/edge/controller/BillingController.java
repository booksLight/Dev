package com.boot.edge.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.boot.edge.mgr.InvtApi;
import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;
import com.boot.edge.mgr.StockApi;
import com.boot.edge.model.master.MasterItem;
import com.boot.edge.ui.InvoiceVO;
import com.boot.edge.ui.StockVO;
import com.boot.edge.util.TransformUtil;

@Controller
@RequestMapping("/bill")
public class BillingController {
	private static final Logger logger = LogManager.getLogger(BillingController.class);
	@Autowired
	private ProductApi productApi;
	
	@Autowired
	private ItemApi itemApi;
	
	@Autowired
	private StockApi stockApi;

	@Autowired
	private InvtApi invApi;
	
	
	@GetMapping("/invoice")
	public String loadBillVoucher(Model model) {
		logger.info(this.getClass()+"loadBillVoucher :START");
		model.addAttribute("products", productApi.getProductsMap());		
		model.addAttribute("items", new HashMap<Long, String>());		
		model.addAttribute("stocks", new HashMap<Long, String>());
		InvoiceVO invo = new InvoiceVO();		
		invo.setInvNo(new TransformUtil().generateInvoiceNumber());
		model.addAttribute("invObj", invo);
		logger.info(this.getClass()+"loadBillVoucher :END");
		new TransformUtil().getThisWeek();
		return "inventory/invoice";
	}
	
	@PostMapping("/add")
	public String createBillVoucher(@ModelAttribute  InvoiceVO invoiceVO) {
		logger.info(this.getClass()+"createBillVoucher :START");
		
		System.out.println("\n Bill Details  ="+invoiceVO.toString());
		invApi.addInventory(invoiceVO);
		logger.info(this.getClass()+"createBillVoucher :END");
		return "redirect:/home";
	}
	
	
	
	
	
	
	
	
}
