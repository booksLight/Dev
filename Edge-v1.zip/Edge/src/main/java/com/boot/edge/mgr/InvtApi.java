package com.boot.edge.mgr;

import java.util.List;

import com.boot.edge.model.Inventory;
import com.boot.edge.ui.InvoiceVO;

public interface InvtApi {
	public void addInventory(Inventory invtPram);
	public Inventory findInventory(Long key);
	public List<Inventory> inventories();
	public void updateInventory(Inventory inventory);
	public void deleteInventory(Long key);
	public void addInventory(InvoiceVO invoiceVO);
}
