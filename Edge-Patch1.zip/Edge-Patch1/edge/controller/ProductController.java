package com.boot.edge.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.boot.edge.model.Inventory;
import com.boot.edge.model.Product;
import com.boot.edge.ui.ProductVO;
import com.boot.edge.ui.Voucher;
import com.boot.edge.mgr.InvtApi;
import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;

@Controller
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private InvtApi invtApi;
	
	@Autowired
	private ProductApi productApi;
	
	@Autowired
	private ItemApi itemApi;

	@RequestMapping(value={"/add"}, method = RequestMethod.GET)
	public String loadProductVoucher(Model model) {
		
		Map<Long, String> productMap = null;
		model.addAttribute("voucher", new ProductVO());

		
		List<Product> productType = productApi.products();
		if(productType !=null) {
			productMap = new HashMap<>();
			for(Product product : productType) {
				productMap.put(product.getId(), product.getType());
			}
		}
	
		model.addAttribute("products", productMap);
		return "addProduct";	
	}
	@RequestMapping(value={"/add"}, method = RequestMethod.POST)
	public String addProduct(@ModelAttribute ProductVO product ) {
	
		System.out.println("\n **** addProduct :"+product.toString());
		return "/home";
	}
	
	
	@RequestMapping(value={"/list"}, method = RequestMethod.GET)
	public void showInventories() {
		List<Product> productType = productApi.products();
		if (productType != null) {
		for (Product product : productType) {
			System.out.println(product.toString());
		}
		}else {
			System.out.println("Product not found.");
		}
	}
	
	//@RequestMapping(value={"/add"}, method = RequestMethod.POST)
	public void addInventory() {
		Inventory invtPram = new Inventory();
		invtApi.addInventory(invtPram);		
	}


	


	
	

	//https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram
	
}
