package com.boot.edge.mgr;

import java.util.List;

import com.boot.edge.model.Inventory;
import com.boot.edge.model.Product;

public interface ProductApi {
	public void addProduct(Product invtPram);
	public Product findProduct(Long key);
	public List<Product> products();
	public void updateProduct(Product product);
	public void deleteProduct(Long key);
}
