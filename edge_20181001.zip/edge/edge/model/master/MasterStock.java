package com.boot.edge.model.master;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="MST_STOCK")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class MasterStock {

	@Id
	@SequenceGenerator(name = "StockSeqGen", sequenceName = "stockSeq", initialValue = 11111, allocationSize = 30)
	@GeneratedValue(generator = "StockSeqGen")	
	private Long id;	
	private String code;
	private String title;
	private Double qty;
	private String uom;
	private Double rate;	
	private String discription;	
	private Double offer;
	private Double value;
	private String isActive;		
	private Long itemCode;
	private Timestamp date;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Double getQty() {
		return qty;
	}
	public void setQty(Double qty) {
		this.qty = qty;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public Double getRate() {
		return rate;
	}
	public void setRate(Double rate) {
		this.rate = rate;
	}
	public String getDiscription() {
		return discription;
	}
	public void setDiscription(String discription) {
		this.discription = discription;
	}
	public Double getOffer() {
		return offer;
	}
	public void setOffer(Double offer) {
		this.offer = offer;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public Long getItemCode() {
		return itemCode;
	}
	public void setItemCode(Long itemCode) {
		this.itemCode = itemCode;
	}
	public Timestamp getDate() {
		return date;
	}
	public void setDate(Timestamp date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "MasterStock [id=" + id + ", code=" + code + ", title=" + title + ", qty=" + qty + ", uom=" + uom
				+ ", rate=" + rate + ", discription=" + discription + ", offer=" + offer + ", value=" + value
				+ ", isActive=" + isActive + ", itemCode=" + itemCode + ", date=" + date + "]";
	}
	
	
}
