package com.boot.edge.ui;

public class ContraVO {
	
	private Integer codeUI;
	private String titleUI;
	private Double rateUI;
	private String qtyUI;
	private String discriptionUI;
	private Double offerUI;
	private String isActive;
	private String productCode;
	private String itemCode;
	
	
	public Integer getCodeUI() {
		return codeUI;
	}
	public void setCodeUI(Integer codeUI) {
		this.codeUI = codeUI;
	}
	
	public String getTitleUI() {
		return titleUI;
	}
	public void setTitleUI(String titleUI) {
		this.titleUI = titleUI;
	}
	public Double getRateUI() {
		return rateUI;
	}
	public void setRateUI(Double rateUI) {
		this.rateUI = rateUI;
	}
	public String getQtyUI() {
		return qtyUI;
	}
	public void setQtyUI(String qtyUI) {
		this.qtyUI = qtyUI;
	}
	public String getDiscriptionUI() {
		return discriptionUI;
	}
	public void setDiscriptionUI(String discriptionUI) {
		this.discriptionUI = discriptionUI;
	}
	public Double getOfferUI() {
		return offerUI;
	}
	public void setOfferUI(Double offerUI) {
		this.offerUI = offerUI;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	
	
}
