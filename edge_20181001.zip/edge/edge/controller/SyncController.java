package com.boot.edge.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ItemManager;
import com.boot.edge.mgr.SyncApi;
import com.boot.edge.mgr.SyncManager;
import com.boot.edge.model.master.MasterItem;
import com.boot.edge.ui.ItemVO;
import com.boot.edge.ui.ProductVO;
import com.boot.edge.ui.StockUI;
import com.boot.edge.ui.StockVO;

@Controller
@RequestMapping("/synch")
public class SyncController {
	private static final Logger logger = LoggerFactory.getLogger(SyncController.class);

	private static final String XSL_FILE = "D://Projects/Source/Template.xlsx";

	@Autowired
	private SyncApi syncMgr;
	
	@Autowired
	private ItemApi itemApi;

	@RequestMapping(value = { "/upload/{type}" }, method = RequestMethod.POST)
	@ResponseBody
	public String loadStock(@PathVariable("type") String uploadKey) {
		logger.debug("It's in SyncController.loadStock("+uploadKey+ "): START");
		List<StockUI> stocks = null;
		String status ="FAILURE";
		try {
			stocks =  getStocksDetails();
			status = "SUCCESS";
		}catch(Exception e) {
			status ="FAILURE :"+e.getMessage();
		}		
		logger.debug("It's in SyncController.loadStock("+uploadKey+ ") : END");
		return status;		
	}
	
	@RequestMapping(value = { "/product" }, method = RequestMethod.GET)
	public void syncProduct() {
		logger.debug("It's in SyncController.syncProduct : START");
		List<ProductVO> products = syncMgr.uploadProduct(XSL_FILE);
		if(products != null && products.size()>0) {
			syncMgr.synchProduct(products);
		}
		logger.debug("It's in SyncController.syncProduct : END");
	}

	@RequestMapping(value = { "/item" }, method = RequestMethod.GET)
	public void syncItem() {
		logger.debug("It's in SyncController.syncItem : START");
		List<ItemVO> items = syncMgr.uploadItem(XSL_FILE);
		if(items != null && items.size()>0) {
			syncMgr.synchItem(items);
		}
		logger.debug("It's in SyncController.syncItem : END");
	}

	
	@RequestMapping(value = { "/stock" }, method = RequestMethod.GET)
	public ModelAndView fetchXlsStock(Model model) {
		logger.debug("It's in SyncController.fetchXlsStock : uploading stocks....");
		ModelAndView mv = new ModelAndView("master/uploadStock");
		try{
			List<StockUI> stocks = getStocksDetails();			
			mv.addObject("stocks", stocks);
		}catch(Exception e) {
			mv.addObject("stocks", new ArrayList<StockUI>());
		}
		
		return mv;		
	}
		
	@RequestMapping(value = { "/stock/upload" }, method = RequestMethod.POST)	
	public String uploadStock()  throws IOException, InvalidFormatException {
		logger.debug("It's in SyncController.uploadStock: START");		
			syncMgr.synchStock(syncMgr.uploadStock(XSL_FILE));		
		logger.debug("It's in SyncController.uploadStock : END");
		
		return "redirect:/home";
	}
	
	private List<StockUI> getStocksDetails() throws IOException, InvalidFormatException {
		List<StockUI> stocks = new ArrayList<StockUI>();
		for(StockVO sv : syncMgr.uploadStock(XSL_FILE)) {
			StockUI stock = new StockUI();
			if(sv.getCode()!=null )		   
			stock.setCode(sv.getCode());
			stock.setDate(sv.getDate());
			stock.setTitle(sv.getTitle());
			stock.setQty(sv.getQty());
			stock.setUom(sv.getUom());
			stock.setMrp(sv.getRate());
			stock.setRate(sv.getValue());
			stock.setpCode(sv.getCode());
			
			if(sv.getCode()!=null && sv.getCode().length()> 1) {
			stock.setItemCode( itemApi.findMasterItemByCode(sv.getCode()) !=null ? itemApi.findMasterItemByCode(sv.getCode()).getId() : -1);
			stocks.add(stock);
			}
		}
		return stocks;
	}
	
}
