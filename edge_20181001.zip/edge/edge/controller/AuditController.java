package com.boot.edge.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.boot.edge.model.Inventory;
import com.boot.edge.model.Item;
import com.boot.edge.model.Stock;
import com.boot.edge.model.master.MasterStock;
import com.boot.edge.util.TransformUtil;
import com.boot.edge.mgr.InvtApi;
import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;
import com.boot.edge.mgr.StockApi;

@Controller
@RequestMapping("/audit")
public class AuditController {

	@Autowired
	private InvtApi invtApi;
	
	@Autowired
	private ProductApi productApi;

	@Autowired
	private ItemApi itemApi;
	
	@Autowired
	private StockApi stockApi;

	
	@GetMapping("/list")
	public List<Item> listItems() {
		List<Item> items = itemApi.items();		
		return items != null ? items : new ArrayList<Item>();			
	}

	

	@GetMapping("/delete")
	public void removeItem() {
		itemApi.updateItem(new Item());
	}


	@SuppressWarnings("deprecation")
	@GetMapping("/profit")
	@ResponseBody
	public Map<String, Integer> getProfits() throws Exception {	
		Map<String, Integer> profitMap = new HashMap<>();
		List<Inventory> invts = invtApi.inventories();
			for(Inventory invt : invts) {									
				profitMap.put(TransformUtil.getMonthForInt(invt.getDate().getMonth()), invt.getQty().intValue());				
			}			
				System.out.println("\n ***** Timestamp Dates ="+profitMap.keySet());
		return profitMap;
	}
	
	@SuppressWarnings("deprecation")
	@GetMapping("/trends")
	@ResponseBody
	public Map<Integer, Integer> getTrends() throws Exception {	
		Map<Integer, Integer> trendsMap = new HashMap<>();
		List<Stock> salesStock = stockApi.stocks();
		if(salesStock !=null) {
			for(Stock stock : salesStock) {							
				trendsMap.put(stock.getQty().intValue(), numberOfPurchased(stock));				
			}			
		}
		System.out.println("\n ***** Timestamp Dates ="+trendsMap.keySet());
		return trendsMap;
	}



	private Integer numberOfPurchased(Stock stock) {
		if(stock!=null) {
			try {
			return stock.getId()>0 ? (stockApi.findMasterStock(stock.getId()) !=null ? stockApi.findMasterStock(stock.getId()).getQty().intValue():0):0;
			}catch(Exception e) {
				System.out.println("ERROR :"+e.getMessage());
			}
		}
		return 0;
	}
	
	// https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram

}
