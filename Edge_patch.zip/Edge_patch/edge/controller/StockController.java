package com.boot.edge.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.boot.edge.model.Item;
import com.boot.edge.model.Product;
import com.boot.edge.model.Stock;
import com.boot.edge.model.master.MasterItem;
import com.boot.edge.model.master.MasterProduct;
import com.boot.edge.model.master.MasterStock;
import com.boot.edge.ui.ItemVO;
import com.boot.edge.ui.StockVO;
import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;
import com.boot.edge.mgr.StockApi;
import com.boot.edge.util.ItemUtil;
import com.boot.edge.util.TransformUtil;

@Controller
@RequestMapping("/stock")
public class StockController {

	@Autowired
	private ProductApi productApi;
	
	@Autowired
	private ItemApi itemApi;
	
	@Autowired
	private StockApi stockApi;

	@GetMapping("/add")
	public String loadStockVoucher(Model model) {
		Map<Long, String> productMap = null;
		Map<Long, String> itemMap = null;
		List<MasterProduct> mproductType = productApi.masterProducts();
		
		if(mproductType !=null) {
			productMap = new HashMap<>();
			for(MasterProduct mproduct : mproductType) {				
				productMap.put(mproduct.getId(), mproduct.getTitle());
			}
		}		
		model.addAttribute("products", productMap);
		
		List<MasterItem> mitemType = itemApi.mitems();
		if(mitemType !=null) {
			itemMap = new HashMap<>();
			for(MasterItem mitem : mitemType) {
				productMap.put(74l, "-select-");
				itemMap.put(mitem.getId(), mitem.getTitle());
			}
		}
		
		model.addAttribute("items", itemMap);
		model.addAttribute("stock", new StockVO());
		return "master/addStock";
	}
	
	@PostMapping("/add")
	public String addMasterStockVoucher(@ModelAttribute StockVO stockVO) {
		if(stockVO != null)
		stockApi.addMasterStock(transform(stockVO));		
		return "redirect:/home";
	}	
	
	
	@GetMapping("/search/{id}")
	@ResponseBody
	public String searchStock(@PathVariable("id") Long key) throws Exception {
		System.out.println("/n ***** Stock Details ID ="+key);
		String result ="";
		MasterStock mstock =null;	
		mstock = key>0 ?  stockApi.findMasterStock(key) :null;	
		System.out.println("/n ***** Stock Details findMasterStock="+mstock.toString());
		return mstock !=null ? new TransformUtil().object2Json(mstock):null;			
	}
	
	@GetMapping("/search")
	public void searchStockByID() {
		Long key=1l;
		itemApi.findItem(key);	
	}
	
	
	@GetMapping("/list")
	public void listStocks() {
		List<Item> items = itemApi.items();
		if(items != null) {
			 System.out.println("\t ****** Listing Items : STRT");
		for(Item it :items) {
			System.out.println(it.getId() + " "+it.getNumber()+ " "+it.getQty()+ " "+it.getStocks().toString());
		}
		 System.out.println("\t ****** Listing Items : END");
		}else {
			System.out.println("Item not founds.");
		}
	}
	
	@GetMapping("/update")
	public void updateStock() {
		Item itm = new ItemUtil().initItem();
		itm.setId(1l);
		itm.setNumber(itm.getNumber()+10);
		itm.setDiscription(itm.getDiscription()+" Updated one..");
		itemApi.updateItem(itm);
		System.out.println("Item "+itm.getId() +" updated successfully.");
		
	}
		
	@GetMapping("/delete")
	public void removeStock() {		
		itemApi.updateItem(new Item());
	}
	
	@PostMapping(value = "/list/{id}")
	@ResponseBody
	public Map<Long, String> findStocksById(@PathVariable("id") Long key) throws Exception {
		Map<Long, String> stockMap = stockApi.getProductItemStocksMap(key);			
		System.out.println("\n****** Stock Found :"+stockMap.toString());
		return stockMap;
	}
	
	private MasterStock transform(StockVO stockVO) {
		MasterStock mstock = new MasterStock();
		mstock.setCode(stockVO.getCode());
		mstock.setTitle(stockVO.getTitle());
		mstock.setDiscription(stockVO.getDiscription());
		mstock.setOffer(stockVO.getOffer());
		mstock.setQty(stockVO.getQty());
		mstock.setRate(stockVO.getRate());
		mstock.setUom(stockVO.getUom());		
		mstock.setValue(mstock.getQty() * mstock.getRate());
		mstock.setIsActive(stockVO.getIsActive());
		mstock.setItemCode(stockVO.getItemCode());				
		System.out.println("\n Master Stock ="+mstock.toString());
		return mstock;
	}
	
	
	//https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram
	
}
