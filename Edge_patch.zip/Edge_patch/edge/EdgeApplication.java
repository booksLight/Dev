package com.boot.edge;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.boot.edge.model.Address;
import com.boot.edge.model.Profile;
import com.boot.edge.model.Role;
import com.boot.edge.model.User;
import com.boot.edge.repo.UserRepository;

@SpringBootApplication
@EnableAutoConfiguration
public class EdgeApplication {

	@Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepository;

    @PostConstruct
    public void init(){
       // Create User
		User user = new User();		
		user.setEmail("test@sharma.com");
		user.setActivated(false);
		user.setProfile(geProfile(user));	      

        if (userRepository.findByEmail(user.getEmail()) == null){
            userRepository.save(user);
        }
    }
    
	public static void main(String[] args) {
		SpringApplication.run(EdgeApplication.class, args);
	}
	
	private Profile geProfile(User user) {
		Profile profile = new Profile();
		profile.setFirstName("Rakesh");
		profile.setLastName("Sharma");
		profile.setMobile("8310319984");
		profile.setPassword(passwordEncoder.encode("password"));
		profile.setAddress(getAddress(profile));
		profile.setVerified(false);
		profile.setUser(user);		
		profile.setRoles(getRoles(profile));	
				
		return profile;
	}

	private Collection<Role> getRoles(Profile profile) {
		Collection<Role> roles = new HashSet<Role>();
		roles.add(new Role("ROLE_USER"));
		profile.setRoles(roles);		
		return roles;
	}

	private Collection<Address> getAddress(Profile profile) {
		// Create Address
		Collection<Address> addresses = new HashSet<Address>();
		Address address = new Address();
		address.setHouseNo("71 1st Floor");
		address.setStreatNo("5th Cross");
		address.setCity("Hebbal");
		address.setState("Karnatka");
		address.setPin(560024);
		address.setPhone("223304402");
		address.setActive(true);
		address.setParmanent(false);
		address.setLocal(true);		
		address.setProfile(profile);
		addresses.add(address);
		return addresses;
	}
}

