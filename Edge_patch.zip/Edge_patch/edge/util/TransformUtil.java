package com.boot.edge.util;

import com.boot.edge.model.MProduct;
import com.boot.edge.model.Product;
import com.boot.edge.ui.ProductVO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TransformUtil {

	public Product transform(ProductVO productVO, Product product) {
		MProduct mproduct = new MProduct();		
		return product;
	}

	public String object2Json(Object obj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return  obj!=null ? objectMapper.writeValueAsString(obj): null;
	}
	
}
