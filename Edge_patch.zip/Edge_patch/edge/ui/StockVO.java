package com.boot.edge.ui;

public class StockVO {
	
	private Long productCode;
	private Long itemCode;	
	private String title;
	private String code;
	
	
	private Double qty;
	private String uom;
	private Double rate;
	
	private String discription;
	
	private Double offer;
	private Double value;
	private String isActive;
	
	public Long getProductCode() {
		return productCode;
	}
	public void setProductCode(Long productCode) {
		this.productCode = productCode;
	}
	public Long getItemCode() {
		return itemCode;
	}
	public void setItemCode(Long itemCode) {
		this.itemCode = itemCode;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Double getQty() {
		return qty;
	}
	public void setQty(Double qty) {
		this.qty = qty;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public Double getRate() {
		return rate;
	}
	public void setRate(Double rate) {
		this.rate = rate;
	}
	public String getDiscription() {
		return discription;
	}
	public void setDiscription(String discription) {
		this.discription = discription;
	}
	public Double getOffer() {
		return offer;
	}
	public void setOffer(Double offer) {
		this.offer = offer;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	@Override
	public String toString() {
		return "StockVO [productCode=" + productCode + ", itemCode=" + itemCode + ", title=" + title + ", code=" + code
				+ ", qty=" + qty + ", uom=" + uom + ", rate=" + rate + ", discription=" + discription + ", offer="
				+ offer + ", value=" + value + ", isActive=" + isActive + "]";
	}
	
}
