package com.boot.edge.mgr;

import java.util.List;

import com.boot.edge.model.Inventory;

public interface InvtApi {
	public void addInventory(Inventory invtPram);
	public Inventory findInventory(Long key);
	public List<Inventory> inventories();
	public void updateInventory(Inventory inventory);
	public void deleteInventory(Long key);
}
