package com.boot.edge.mgr;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.boot.edge.model.Item;
import com.boot.edge.model.Product;
import com.boot.edge.model.Stock;
import com.boot.edge.repo.ItemRepository;
import com.boot.edge.repo.ProductRepository;
import com.boot.edge.util.ItemUtil;

@Component
public class ProductManager implements ProductApi {

	@Autowired
	private ProductRepository productRepository;

	@Override
	public void addProduct(Product invtPram) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Product findProduct(Long key) {
		// TODO Auto-generated method stub
		return productRepository.getOne(key);
	}

	@Override
	public List<Product> products() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public void updateProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProduct(Long key) {
		// TODO Auto-generated method stub
		
	}
	
	
}
