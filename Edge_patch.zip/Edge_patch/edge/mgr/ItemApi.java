package com.boot.edge.mgr;

import java.util.List;
import com.boot.edge.model.Item;

public interface ItemApi {

	public void addItem(Item item);
	public Item findItem(Long key);
	public List<Item> items();
	public void updateItem(Item item);
	public void deleteItem(Long key);
}
