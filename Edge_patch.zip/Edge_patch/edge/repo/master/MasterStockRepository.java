package com.boot.edge.repo.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.boot.edge.model.master.MasterStock;

@Repository
public interface MasterStockRepository extends JpaRepository<MasterStock, Long>{

	MasterStock findMasterStockByCode(String code);
	List<MasterStock> findMasterStockByItemCode(Long itemCodeKey);
}
