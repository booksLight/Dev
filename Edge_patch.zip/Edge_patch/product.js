$(document).ready(
		function() {

			var findItemURL = "/item/list/";
			
			// START : Fetching Items based on product : Author@Raesh			
			$("#selectProduct").change(
					function() {
						debugger;
						var prodId = $("#selectProduct option:selected").val();
						console.log("selected Product =" + prodId);

						$.ajax({
							url : findItemURL + prodId,
							type : 'POST',
							success : function(result) {
								$("#selectItem").html("");
								$.each(result, function(key, val) {
									$("#selectItem").append(
											$('<option></option>').val(key)
													.html(val))
								})
							},
							error : function() {
								alert("Whooaaa! Something went wrong..")
							},
						});
					});
			 // END :Fetching Items based on product : Author@Raesh	
			
			// START : Fetching Items based on product : Author@Raesh	
			var findStockURL = "/stock/list/";								
			$("#selectItem").change(
					function() {
						debugger;
						var itemId = $("#selectItem option:selected").val();
						console.log("selected Item =" + itemId);

						$.ajax({
							url : findStockURL+itemId,
							type : 'POST',
							success : function(result) {
								$("#selectStock").html("");
								$.each(result, function(key, val) {
									$("#selectStock").append(
											$('<option></option>').val(key)
													.html(val))
								})
							},
							error : function() {
								alert("Whooaaa! Something went wrong with finding stock..")
							},
						});
					});
			 // END :Fetching Items based on product : Author@Raesh	
			
	
			// START : Fetching Stock details based on select : Author@Raesh	
			var findStockDetURL = "/stock/search/";								
			$("#selectStock").change(
					function() {
						debugger;
						var stockId = $("#selectStock option:selected").val();
						console.log("selected Stock =" + stockId);
						$.ajax({
							url : findStockDetURL + stockId,
							type : 'GET',
							success : function(result) {
							console.log(result)
								$("#stockcode").html(result.code);
							},
							error : function() {
								alert("Whooaaa! Something went wrong..")
							},
						});
					});
			 // END :Fetching Stock details based on select  : Author@Raesh	
			
			
			
		});