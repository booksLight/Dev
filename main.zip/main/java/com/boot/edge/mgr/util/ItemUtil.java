package com.boot.edge.mgr.util;

import java.util.Collection;
import java.util.HashSet;

import com.boot.edge.model.Item;
import com.boot.edge.model.Stock;

public class ItemUtil {

	public Item initItem() {
		Item item = new Item();
		item.setNumber(9765);	
		item.setType("IceCream-2");
		item.setDiscount(0d);
		item.setQty(33.0);		
		item.setDiscription("Scotch");		
		item.setStocks(initStocks(item));	
		return item;
	}
		
	public Collection<Stock> initStocks(Item item) {
		Collection<Stock> stocks = new HashSet<Stock>();
		Stock stock = new Stock();
		stock.setNumber(6840);
		stock.setType("Editable");
		stock.setRate(33.8d);		
		stock.setUom("GRM");
		stock.setDiscription("New");
		stock.setItem(item);
		stocks.add(stock);
		return stocks;
	}

}
