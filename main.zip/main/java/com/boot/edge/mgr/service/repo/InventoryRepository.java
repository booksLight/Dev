package com.boot.edge.mgr.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.boot.edge.model.Inventory;

@Repository
public interface InventoryRepository extends JpaRepository<Inventory, Long>{

	Inventory findInventoryByInvoice(String invoice);
}
