package com.boot.edge.mgr;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.boot.edge.model.Inventory;
import com.boot.edge.mgr.service.repo.InventoryRepository;
import com.boot.edge.mgr.util.InvtUtil;

@Component
public class InventoryManager implements InvtApi{

	@Autowired
	private InventoryRepository inventoryRepository;

	@Override
	public void addInventory(Inventory invtPram) {
		Inventory invt = new InvtUtil().getInventory();
		if(invt != null) {
			System.out.println("InventoryRepository invokation : START");
			inventoryRepository.save(invt);
			System.out.println("InventoryRepository invokation : END");
			System.out.println("\n Inventory added successfully...");
		}else {
			System.out.println("Inventory is null");
		}			
	}

	@Override
	public Inventory findInventory(Long key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Inventory> inventories() {
		// TODO Auto-generated method stub
		return inventoryRepository.findAll();
	}

	@Override
	public void updateInventory(Inventory inventory) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteInventory(Long key) {
		// TODO Auto-generated method stub
		
	}
}
