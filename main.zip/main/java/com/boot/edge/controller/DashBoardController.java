package com.boot.edge.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.boot.edge.mgr.ItemApi;

@Controller
public class DashBoardController {

	@Autowired
	private ItemApi itemApi;
	
	public ModelAndView login3(){
		System.out.println("\n ****** DashBoardController.login ::START\n");
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		System.out.println("\n ****** DashBoardController.login ::END\n");
		return modelAndView;
	}
	
	@RequestMapping("/")
	public ModelAndView index( ) {
		ModelAndView mv = new ModelAndView("index");
		mv.addObject("item", itemApi.items());
		return mv;
	}
	
	@RequestMapping(value={"/login"}, method = RequestMethod.GET)
	public String login() {
		return "login";
	}

	@RequestMapping("/register")
	public String register() {
		return "register";
	}

	@RequestMapping("/forget-pass")
	public String forget_pass() {
		return "forget-pass";
	}

	@RequestMapping("/chart")
	public String chart() {
		return "chart";
	}
	
	@RequestMapping("/table")
	public String table() {
		return "table";
	}
	
	@RequestMapping("/form")
	public String form() {
		return "form";
	}
	
	@RequestMapping("/map")
	public String map() {
		return "map";
	}	
	
	@RequestMapping("/alert")
	public String alert() {
		return "alert";
	}	
	
	
	@RequestMapping("/card")
	public String card() {
		return "card";
	}	
	
	@RequestMapping("/tab")
	public String tab() {
		return "tab";
	}	
	
	@RequestMapping("/badge")
	public String badge() {
		return "badge";
	}	
	
	@RequestMapping("/button")
	public String button() {
		return "button";
	}	
	
	@RequestMapping("/progress-bar")
	public String progress_bar() {
		return "progress-bar";
	}	
	@RequestMapping("/modal")
	public String modal() {
		return "modal";
	}	
		
	@RequestMapping("/switch")
	public String switchs() {
		return "switch";
	}	
	
	@RequestMapping("/grid")
	public String grid() {
		return "grid";
	}	
	
	@RequestMapping("/fontawesome")
	public String fontawesome() {
		return "fontawesome";
	}	
	
	@RequestMapping("/typo")
	public String typo() {
		return "typo";
	}	
	
}
