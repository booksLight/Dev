package com.boot.edge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.boot.edge.model.Inventory;
import com.boot.edge.mgr.InvtApi;

@RestController
@RequestMapping("/invt")
public class InventoryController {

	@Autowired
	private InvtApi invtApi;

	@GetMapping("/list")
	public void showInventories() {
		List<Inventory> inventories = invtApi.inventories();
		if (inventories != null) {
		for (Inventory invt : inventories) {
			System.out.println(invt.toString());
		}
		}else {
			System.out.println("Inventory not found.");
		}
	}
	
	@GetMapping("/add")
	public void addInventory() {
		Inventory invtPram = new Inventory();
		invtApi.addInventory(invtPram);		
	}

	
	@GetMapping("/voucher")
	public ModelAndView getVoucher() {
		ModelAndView mv = new ModelAndView("voucher");
		return mv;	
	}


	
	

	//https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram
	
}
