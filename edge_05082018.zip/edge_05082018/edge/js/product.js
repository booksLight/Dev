	$(document).ready(				
		function() {						
			var findItemURL = "/item/list/";				
			// START : Fetching Items based on product : Author@Raesh			
			$("#selectProduct").change(
					function() {
						debugger;
						var prodId = $("#selectProduct option:selected").val();
						console.log("selected Product =" + prodId);						
						$.ajax({
							url : findItemURL+prodId,
							type : 'POST',
							async:false ,
							success : function(result) {								
								$('#selectItem').empty().append('<option selected="selected" value="-999">--select--</option>');
								$.each(result, function(key, val) {
									$("#selectItem").append(
											$('<option></option>').val(key)
													.html(val))
								})
								callRest();
							},
							error : function() {
								alert("Whooaaa! Something went wrong while selectivn product..");
								callRest();
							},
						});
					});
			 // END :Fetching Items based on product : Author@Raesh	
			
			// START : Fetching Items based on product : Author@Raesh	
			var findStockURL = "/stock/list/";								
			$("#selectItem").change(
					function() {
						debugger;
						var itemId = $("#selectItem option:selected").val();
						console.log("selected Item =" + itemId);
					
						$.ajax({
							url : findStockURL+itemId,
							type : 'POST',
							async:false ,
							success : function(result) {			
								$('#selectStock').empty().append('<option selected="selected" value="-999">--select--</option>');
								$.each(result, function(key, val) {
									$("#selectStock").append(
											$('<option></option>').val(key)
													.html(val))
								})
							},
							error : function() {
								alert("Whooaaa! Something went wrong with finding stock..")
							},
						});
					});
			 // END :Fetching Items based on product : Author@Raesh	
			
	
			// START : Fetching Stock details based on select : Author@Rakesh	
			var findStockDetURL = "/stock/search/";								
			$("#selectStock").change(
					function() {
						debugger;
						var stockId = $("#selectStock option:selected").val();
						console.log("selected Stock =" + stockId);						
						$.ajax({
							url : findStockDetURL + stockId,
							type : 'GET',
							async:false ,
							success : function(result) {
							var json = JSON.parse(result);
							console.log(json);	
							if(json.qty < 1){								
								$.alert({
								    title: '<font color="red"><b>Satyam Alert!</b></font>',
								    content: '<font color="red">Insufficient Stock!</font> <br/><font color="blue">Removing now...</font>',
								});		
								$("#selectStock option[value="+json.id+"]").remove();
								initRest();								
								$("#btnSubmit").addClass("disabled"); 
								return;
							}else{
							 	$("#stockQty").val(1);
								$("#stockDiscription").val(json.discription);
								$("#stockUom").val(json.uom);								
								$("#stockSum").val(json.rate * 1);																	
								$("#stockCode").html(json.code);
								$("#stockRate").html(json.rate);
								$("#stockInHand").html(json.qty);
								$("#stockComment").html(json.discription);
								$("#btnSubmit").removeAttr("disabled"); 
								$("#btnSubmit").addClass("fa fa-dot-circle-o btn btn-primary btn-10m");
							}
							},
							error : function() {
								alert("Whooaaa! Something went wrong..")
							},
						});
					});
			 // END :Fetching Stock details based on select  : Author@Raesh	
			
			$('#stockQty').change(function () {	            
	            var rate = $("#stockRate").text();
	            $("#stockSum").val(this.value * rate);	            
	        });
			
			
			
			var findSelectItemURL = "/item/list/";
			
			// START : Fetching Items based on product : Author@Raesh			
			$("#selectStockProduct").change(
					function() {
						debugger;
						var stockProdId = $("#selectStockProduct option:selected").val();
						console.log("selected Stock Product =" + stockProdId);		
					
						$.ajax({
							url : findSelectItemURL+stockProdId,
							type : 'POST',
							async:false ,
							success : function(result) {	
								$('#selectStockItem').empty().append('<option selected="selected" value="-999">--select--</option>');								
								$.each(result, function(key, val) {
									$("#selectStockItem").append(
											$('<option></option>').val(key)
													.html(val))
								})
							},
							error : function() {
								alert("Whooaaa! Something went wrong while select product itemmt..")
							},
						});
					});
			 // END :Fetching Items based on product : Author@Rakesh	
			
			function initRest(){
				$("#stockQty").val(0);
				$("#stockDiscription").val("");
				$("#stockUom").val(" ");								
				$("#stockSum").val(0.0);																
				$("#stockCode").html("");
				$("#stockRate").html(0);
				$("#stockInHand").html(0);
				$("#stockComment").html("");	
				$("#btnSubmit").removeClass("fa fa-dot-circle-o btn btn-primary btn-10m");
				$("#btnSubmit").addClass("disabled"); 
			}			
			
			function callRest() {
						$("#cbs").attr('disabled', 'disabled');
						$("#btnSubmit").removeClass(
								"fa fa-dot-circle-o btn btn-primary btn-10m");

			}	
			
		});
	
	