package com.boot.edge.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;
import com.boot.edge.mgr.StockApi;
import com.boot.edge.model.master.MasterItem;
import com.boot.edge.model.master.MasterProduct;
import com.boot.edge.model.master.MasterStock;
import com.boot.edge.ui.InventoryVO;
import com.boot.edge.ui.InvoiceVO;
import com.boot.edge.ui.ItemVO;
import com.boot.edge.ui.ProductVO;
import com.boot.edge.ui.StockItemVO;
import com.boot.edge.ui.StockVO;
import com.boot.edge.util.TransformUtil;



@Controller
@RequestMapping("/")
public class DashBoardController {

	@Autowired
	private ProductApi productApi;
	
	@Autowired
	private ItemApi itemApi;
	
	@Autowired
	private StockApi stockApi;
		
	@RequestMapping(value={"/home"}, method = RequestMethod.GET)
	public ModelAndView loadHome(Model model) {
		Map<Long, String> productMap = null;
		Map<Long, String> itemMap = null;
		List<MasterProduct> mproductType = null;

		ModelAndView mv = new ModelAndView("index");
		mv.addObject("stocks", getStockByProduct());
		mv.addObject("topItems", getTopItems());

		model.addAttribute("products", productApi.getProductsMap());
		model.addAttribute("items", new HashMap<Long, String>());
		model.addAttribute("stocks", new HashMap<Long, String>());
		InvoiceVO invo = new InvoiceVO();
		invo.setInvNo(new TransformUtil().generateInvoiceNumber());
		model.addAttribute("invObj", invo);

		// Stock
		mproductType = productApi.masterProducts();
		if (mproductType != null) {
			productMap = new HashMap<>();
			for (MasterProduct mproduct : mproductType) {
				productMap.put(mproduct.getId(), mproduct.getTitle());
			}
		}
		model.addAttribute("products", productMap);
		List<MasterItem> mitemType = itemApi.mitems();
		if (mitemType != null) {
			itemMap = new HashMap<>();
			for (MasterItem mitem : mitemType) {
				productMap.put(74l, "-select-");
				itemMap.put(mitem.getId(), mitem.getTitle());
			}
		}

		model.addAttribute("items", itemMap);
		model.addAttribute("stock", new StockVO());

		// Item
		mproductType = productApi.masterProducts();
		if (mproductType != null) {
			productMap = new HashMap<>();
			for (MasterProduct product : mproductType) {
				productMap.put(product.getId(), product.getTitle());
			}
		}
		model.addAttribute("products", productMap);
		model.addAttribute("item", new ItemVO());

		//Product		
		model.addAttribute("voucher", new ProductVO());		
		 mproductType = productApi.masterProducts();
		if(mproductType !=null) {
			productMap = new HashMap<>();
			for(MasterProduct product : mproductType) {			
				productMap.put(product.getId(), product.getTitle());
			}
		}	
		model.addAttribute("products", productMap);
		
		return mv;
	}
	

	@RequestMapping(value={"/login"}, method = RequestMethod.GET)
	public String login() {
		return "login";
	}

	@RequestMapping("/register")
	public String register() {
		return "register";
	}

	@RequestMapping("/forget-pass")
	public String forget_pass() {
		return "forget-pass";
	}

	@RequestMapping("/chart")
	public String chart() {
		return "chart";
	}
	
	@RequestMapping("/table")
	public String table() {
		return "table";
	}
	
	@RequestMapping("/form")
	public String form() {
		return "form";
	}
	
	@RequestMapping("/map")
	public String map() {
		return "map";
	}	
	
	@RequestMapping("/alert")
	public String alert() {
		return "alert";
	}	
	
	
	@RequestMapping("/card")
	public String card() {
		return "card";
	}	
	
	@RequestMapping("/tab")
	public String tab() {
		return "tab";
	}	
	
	@RequestMapping("/badge")
	public String badge() {
		return "badge";
	}	
	
	@RequestMapping("/button")
	public String button() {
		return "button";
	}	
	
	@RequestMapping("/progress-bar")
	public String progress_bar() {
		return "progress-bar";
	}	
	@RequestMapping("/modal")
	public String modal() {
		return "modal";
	}	
		
	@RequestMapping("/switch")
	public String switchs() {
		return "switch";
	}	
	
	@RequestMapping("/grid")
	public String grid() {
		return "grid";
	}	
	
	@RequestMapping("/fontawesome")
	public String fontawesome() {
		return "fontawesome";
	}	
	
	@RequestMapping("/typo")
	public String typo() {
		return "typo";
	}	
	
	private List<StockItemVO> getStockByProduct() {
		MasterItem mitem;
		MasterProduct mproduct;
		StockItemVO sv=null;		
		List<StockItemVO> svs = new ArrayList<>();			
		List<MasterStock> mstocks =stockApi.mstocks();
		
		for(MasterStock stock : mstocks) {
			 mitem = itemApi.findMasterItem(stock.getItemCode());
			 mproduct = productApi.findMasterProduct(mitem.getProdId());
			 sv = new StockItemVO(); 
			 sv.setProductType(mproduct.getTitle());
			 sv.setItemType(mitem.getTitle());
			 sv.setCode(mitem.getCode());
			 sv.setTitle(stock.getTitle());			 			
			 sv.setQty(stock.getQty());			
			 sv.setUom(stock.getUom());
			 sv.setRate(stock.getRate());
			 sv.setValue(stock.getValue());
			 sv.setOffer(mitem.getDiscount());
			 sv.setIsActive(stock.getIsActive());
			 svs.add(sv);
		}
		return svs;
	}

	private List<StockItemVO> getTopItems() {
		List<StockItemVO> svs = null;
		svs = getStockByProduct();
		Map<String, Integer> stockMap = getStockQTYByProduct(svs);
		svs = map2List(stockMap);
		System.out.println("\n\t **** Natural ******");
		audit(svs);
		// Sort by address.
		Collections.sort(svs, StockItemVO.COMPARE_BY_STOCK_QTY);
		System.out.println("\n\t **** Ordered By STOCK_QTY ******");
		audit(svs);		
		
		System.out.println("\n\t ****Descending Ordered By STOCK_QTY ******");
		Collections.reverse(svs);
		audit(svs);		
		
		return svs;
	}
	public void audit(List<StockItemVO> svs) {
		for(StockItemVO sv : svs) {
			System.out.println("\n Product:"+sv.getProductType()+", Item:"+sv.getItemType()+", Stock:"+sv.getTitle()+", QTY:"+sv.getQty());
		}
	}
	
	
	public Map<String, Integer> getStockQTYByProduct(List<StockItemVO> svs) {
		Map<String, Integer> invtMap = new HashMap<>();
		for (StockItemVO siv : svs) {
		
			if (invtMap.containsKey(siv.getCode())) {
				Integer sqty = invtMap.get(siv.getCode());
				sqty += siv.getQty().intValue();
				invtMap.put(siv.getItemType(), sqty);
			} else {
				invtMap.put(siv.getItemType(), siv.getQty().intValue());
			}
		}
		for (String key : invtMap.keySet()) {
			System.out.println("\n\t Inventory Qty by Date[ KEY:" + key + ", QTY:" + invtMap.get(key) + "]");
		}
		return invtMap;

	}
	

	private List<StockItemVO> map2List(Map<String, Integer> stockMap) {			
		List<StockItemVO> svs = new ArrayList<>();	
		StockItemVO sv=null;	
		if(stockMap!=null) {
			for (String key : stockMap.keySet()) {
				sv = new StockItemVO();
				sv.setTitle(key);
				sv.setQty(stockMap.get(key).doubleValue());	
				svs.add(sv);
			}
		}
		return svs;
	}
	
}
