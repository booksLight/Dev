package com.boot.edge.mgr;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.boot.edge.model.Inventory;
import com.boot.edge.model.Item;
import com.boot.edge.model.Product;
import com.boot.edge.model.Stock;
import com.boot.edge.model.master.MasterItem;
import com.boot.edge.model.master.MasterProduct;
import com.boot.edge.model.master.MasterStock;
import com.boot.edge.repo.InventoryRepository;
import com.boot.edge.ui.InventoryVO;
import com.boot.edge.ui.InvoiceVO;
import com.boot.edge.ui.ProductVO;
import com.boot.edge.ui.StockItemVO;
import com.boot.edge.util.TransformUtil;

@Component
public class InventoryManager implements InvtApi {

	@Autowired
	private InventoryRepository inventoryRepository;

	@Autowired
	private ProductApi productApi;

	@Autowired
	private ItemApi itemApi;

	@Autowired
	private StockApi stockApi;

	@Autowired
	private InvtApi invApi;

	Inventory invt = null;
	Product prod = null;
	Item item = null;
	Stock stock = null;

	@Override
	public void addInventory(Inventory invtPram) {
		if (invt != null) {
			System.out.println("InventoryRepository invokation : START");
			inventoryRepository.save(invt);

			System.out.println("InventoryRepository invokation : END");
			System.out.println("\n Inventory added successfully...");
		} else {
			System.out.println("Inventory is null");
		}
	}

	@Override
	public Inventory findInventory(Long key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Inventory> inventories() {
		// TODO Auto-generated method stub
		return inventoryRepository.findAll();
	}

	@Override
	public void updateInventory(Inventory inventory) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteInventory(Long key) {
		// TODO Auto-generated method stub

	}

	@Override
	public void addInventory(InvoiceVO invoiceVO) {
		System.out.println("\n\n\t Invoice VO addInventory =" + invoiceVO.toString());
		Collection<Product> invProducts = null;
		MasterProduct prodRef = null;
		MasterItem itemRef = null;
		MasterStock stockRef = null;

		if (invoiceVO != null) {

			/*
			 * invProducts = new HashSet<>(); prodRef =
			 * fetchMasterProduct(invoiceVO.getInvProdCode()); itemRef =
			 * fetchMasterItem(invoiceVO.getInvItemCode()); stockRef =
			 * stockApi.findMasterStock(invoiceVO.getInvStockCode());
			 */
			invApi.addInventory(initInventory(invoiceVO));

			System.out.println("\n********* Bill got saved .......");
		}

	}

	@Override
	public Map<String, Integer> soldItemQtyByDate(List<StockItemVO> sivos) {
		Map<String, Integer> stocksMap = new HashMap<>();
		StockItemVO siv = null;
		String dtd = new SimpleDateFormat("yyyy-MM-dd").format(sivos.get(0).getDate());

		String cdtd = null;
		Double sQty = 0.0;
		for (StockItemVO sv : sivos) {

			String iDate = new SimpleDateFormat("yyyy-MM-dd").format(sv.getDate());
			if (stocksMap.containsKey(iDate)) {
				Integer extv = stocksMap.get(iDate);
				extv += sv.getQty().intValue();
				stocksMap.put(iDate, extv);
			} else {
				stocksMap.put(iDate, sv.getQty().intValue());
			}
		}

		for (String key : stocksMap.keySet()) {
			System.out.println("\n\t Stock Qty by Date[ KEY:" + key + ", QTY:" + stocksMap.get(key) + "]");
		}
		return stocksMap;
	}

	private Inventory initInventory(InvoiceVO invoiceVO) {
		System.out.println("\n\n\t Invoice VO initInventory =" + invoiceVO.toString());
		Double invQty = 0.0;
		invt = new Inventory();
		invt.setDate(new Timestamp(new Date().getTime()));
		invt.setNumber(invoiceVO.getInvNo().toString());

		initProducts(invoiceVO, invt);
		for (Product prod : invt.getProducts()) {
			for (Item item : prod.getItems()) {
				invQty += item.getQty();
			}
		}
		invt.setQty(invQty);

		invt.setStatus(true);
		invt.setValue(invoiceVO.getValue());
		System.out.println("\n ***\n Inventory Payload =" + invt.toString());
		return invt;
	}

	public List<InventoryVO> transform(List<Inventory> inventories) {
		InventoryVO invVo = null;
		List<InventoryVO> invVos = null;
		if (inventories != null) {
			invVos = new ArrayList<InventoryVO>();
			for (Inventory invt : inventories) {
				invVo = new InventoryVO();
				invVo.setId(invt.getId());
				invVo.setNumber(invt.getNumber());
				invVo.setQty(invt.getQty());
				invVo.setValue(invt.getValue());
				// invVo.setStatus(invt.);
				invVo.setDate(invt.getDate());
				invVos.add(invVo);
			}
		}
		return invVos;
	}

	public List<InventoryVO> getTopInventories(List<InventoryVO> invos) {
		audit(invos);
		Collections.sort(invos, InventoryVO.COMPARE_BY_STOCK_DATE);
		System.out.println("\n\t **** Ordered By Inventory DATE ******");
		Collections.reverse(invos);
		audit(invos);
		return invos;
	}

	public void audit(List<InventoryVO> invts) {
		for (InventoryVO invt : invts) {
			System.out.println("\n Inventory Number:" + invt.getNumber() + ", QTY:" + invt.getQty() + ", Value:"
					+ invt.getValue() + ", DATE:" + invt.getDate());
		}
	}

	private void initProducts(InvoiceVO invoiceVO, Inventory inventory) {
		System.out.println("\n\n\t Invoice VO initProducts =" + invoiceVO.toString());
		Collection<Product> products = new ArrayList<>();
		prod = new Product();
		prod.setInventory(inventory);
		initItems(invoiceVO, prod);
		products.add(prod);
		inventory.setProducts(products);
	}

	private void initItems(InvoiceVO invoiceVO, Product prod) {
		System.out.println("\n\n\t Invoice VO initItems =" + invoiceVO.toString());
		Collection<Item> items = new ArrayList<>();
		Double itmQty = 0.0;
		item = new Item();

		Collection<Stock> stocks = initStocks(invoiceVO, item);
		item.setStocks(stocks);

		for (Stock stk : stocks) {
			itmQty += stk != null ? stk.getQty() : 0.0;
		}
		item.setQty(itmQty);
		items.add(item);
		prod.setItems(items);
	}

	private Collection<Stock> initStocks(InvoiceVO invoiceVO, Item item) {
		System.out.println("\n\n\t Invoice VO initStocks =" + invoiceVO.toString());
		Collection<Stock> stocks = new HashSet<>();
		stock = new Stock();
		stock.setQty(invoiceVO.getInvQty());
		stock.setItem(item);
		stocks.add(stock);
		return stocks;
	}

	private MasterProduct fetchMasterProduct(final Long key) {
		return key > 0 ? productApi.findMasterProduct(key) : new MasterProduct();
	}

	private MasterItem fetchMasterItem(final Long key) {
		return key > 0 ? itemApi.findMasterItem(key) : new MasterItem();
	}

	private List<MasterItem> findMasterItemByProdId(final Long key) {
		return key > 0 ? itemApi.findMasterItemByProdId(key) : new ArrayList<MasterItem>();
	}

	private MasterStock fetchMasterStock(final Long key) {
		return key > 0 ? stockApi.findMasterStock(key) : new MasterStock();
	}

	@Override
	public Map<String, Integer> getInventoryQtyByDate(List<InventoryVO> invtVos) {
		Map<String, Integer> invtMap = new HashMap<>();
		for (InventoryVO inv : invtVos) {
			String iDate = new SimpleDateFormat("yyyy-MM-dd").format(inv.getDate());
			if (invtMap.containsKey(iDate)) {
				Integer extv = invtMap.get(iDate);
				extv += inv.getQty().intValue();
				invtMap.put(iDate, extv);
			} else {
				invtMap.put(iDate, inv.getQty().intValue());
			}
		}
		for (String key : invtMap.keySet()) {
			System.out.println("\n\t Inventory Qty by Date[ KEY:" + key + ", QTY:" + invtMap.get(key) + "]");
		}
		return invtMap;

	}
}
