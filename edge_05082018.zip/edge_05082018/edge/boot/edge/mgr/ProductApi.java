package com.boot.edge.mgr;

import java.util.List;
import java.util.Map;

import com.boot.edge.model.Product;
import com.boot.edge.model.master.MasterProduct;

public interface ProductApi {
	
	public void addMasterProduct(MasterProduct mProduct);
	public MasterProduct findMasterProduct(Long mProductKey);
	public List<MasterProduct> masterProducts();
	public void updateMasterProduct(MasterProduct mproduct);
	public void deleteMasterProduct(Long mProductKey);
	
	public void addProduct(Product invtPram);
	public Product findProduct(Long key);
	public List<Product> products();
	public void updateProduct(Product product);
	public void deleteProduct(Long key);
	
	
	public Map<Long, String> getProductsMap();
	
}
