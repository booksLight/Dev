package com.boot.edge.ui;

import java.sql.Timestamp;
import java.util.Comparator;

public class StockItemVO {
		
	
	private String productType;
	private String itemType;
	
	private String code;
	private String title;
	private Double qty;
	private String uom;
	private Double rate;
	private Double offer;	
	private Double value;
	private String isActive;
	private Timestamp date;
	
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Double getQty() {
		return qty;
	}
	public void setQty(Double qty) {
		this.qty = qty;
	}
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public Double getRate() {
		return rate;
	}
	public void setRate(Double rate) {
		this.rate = rate;
	}
	public Double getOffer() {
		return offer;
	}
	public void setOffer(Double offer) {
		this.offer = offer;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public Timestamp getDate() {
		return date;
	}
	public void setDate(Timestamp date) {
		this.date = date;
	}
	
	public static Comparator<StockItemVO> COMPARE_BY_PRODUCT = new Comparator<StockItemVO>() {
        public int compare(StockItemVO one, StockItemVO other) {
            return one.productType.compareTo(other.productType);
        }
    };

    public static Comparator<StockItemVO> COMPARE_BY_ITEM = new Comparator<StockItemVO>() {
        public int compare(StockItemVO one, StockItemVO other) {
            return one.itemType.compareTo(other.itemType);
        }
    };
    
    public static Comparator<StockItemVO> COMPARE_BY_STOCK = new Comparator<StockItemVO>() {
        public int compare(StockItemVO one, StockItemVO other) {
            return one.title.compareTo(other.title);
        }
    };
    
    public static Comparator<StockItemVO> COMPARE_BY_STOCK_QTY = new Comparator<StockItemVO>() {
        public int compare(StockItemVO one, StockItemVO other) {
            return one.qty.compareTo(other.qty);
        }
    };
    
    public static Comparator<StockItemVO> COMPARE_BY_STOCK_DATE = new Comparator<StockItemVO>() {
        public int compare(StockItemVO one, StockItemVO other) {
            return one.date.compareTo(other.date);
        }
    };
    
    
}
