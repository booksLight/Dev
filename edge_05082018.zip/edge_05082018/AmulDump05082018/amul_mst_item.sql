-- MySQL dump 10.13  Distrib 5.6.23, for Win32 (x86)
--
-- Host: localhost    Database: amul
-- ------------------------------------------------------
-- Server version	5.7.22-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mst_item`
--

DROP TABLE IF EXISTS `mst_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `discription` varchar(255) DEFAULT NULL,
  `prod_id` bigint(20) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKals1xcw5m81hrap46mkjwjgcd` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=1625 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_item`
--

LOCK TABLES `mst_item` WRITE;
/*!40000 ALTER TABLE `mst_item` DISABLE KEYS */;
INSERT INTO `mst_item` VALUES (1000,'HLKS',0,'Horlicks',7,'Horlicks'),(1001,'HLKSELVT',0,'Boost Elevate',7,'Boost Elevate'),(1002,'HLKSBPLS',0,'Boost Plus',7,'Boost Plus'),(1003,'HLKSBISC',0,'Horlicka Biscuits',7,'Horlicka Biscuits'),(1004,'HLKSCRTON',0,'Horlicks Cartoon',7,'Horlicks Cartoon'),(1005,'HLKSCHKDLT',0,'Horlicks Chocolate Delight',7,'Horlicks Chocolate Delight'),(1006,'HLKSJAR',0,'Horlicks Jaar',7,'Horlicks Jaar'),(1007,'HLKSPBISC',0,'Horlicks Plain Biscuits',7,'Horlicks Plain Biscuits'),(1008,'HLKSJNR',0,'Junior Horlicks',7,'Junior Horlicks'),(1009,'HLKSJNRV',0,'Junior Horlicks Vannila',7,'Junior Horlicks Vannila'),(1100,'BISKCATPTA',0,'Chatapta Spicy',6,'Chatapta Spicy'),(1101,'BISKGGLY',0,'Googly',6,'Googly'),(1102,'BISKMRIA',0,'Marie',6,'Marie'),(1103,'BISKNECOF',0,'Nestle Coffi',6,'Nestle Coffi'),(1104,'BISKTOP',0,'The Top',6,'The Top'),(1200,'NSLEMAGI',0,'Maggi',5,'Maggi'),(1201,'NSLEMAGIFP',0,'Maggi Famely Pack',5,'Maggi Famely Pack'),(1202,'NSLEMAGIMSLA',0,'Maggi Masala',5,'Maggi Masala'),(1203,'NSLEMNCH',0,'Munch',5,'Munch'),(1204,'NSLECOFI',0,'Nestle Coffi',5,'Nestle Coffi'),(1300,'BRITGERAMSTI',0,'50-50 Geera Masti',4,'50-50 Geera Masti'),(1301,'BRITTIMPAS',0,'50-50 Time Pass',4,'50-50 Time Pass'),(1302,'BRITTOP50',0,'50-50 Top',4,'50-50 Top'),(1303,'BRITBRNBON',0,'Bourn Bon',4,'Bourn Bon'),(1304,'BRITCAKCHOCHL',0,'Cake Choco Chill',4,'Cake Choco Chill'),(1305,'BRITCAKFUTN',0,'Cake Fruity Fun',4,'Cake Fruity Fun'),(1306,'BRITCAKPINAPLE',0,'Cake Pine Apple',4,'Cake Pine Apple'),(1307,'BRITSUGFRE',0,'Cracker Suger Free',4,'Cracker Suger Free'),(1308,'BRITGHE',0,'Ghee',4,'Ghee'),(1309,'BRITGDAY',0,'Good Day',4,'Good Day'),(1310,'BRITLIPOP',0,'Loli Pop',4,'Loli Pop'),(1311,'BRITMLELGHT',0,'Marie Light',4,'Marie Light'),(1312,'BRITMGOLD',0,'Marigold',4,'Marigold'),(1313,'BRITNICREM',0,'Nice Creame',4,'Nice Creame'),(1314,'BRITRSK',0,'Premium Bake Rusk',4,'Premium Bake Rusk'),(1315,'BRITTOP',0,'Top',4,'Top'),(1316,'BRITTOSMORNG',0,'Traet O\'som Orange',4,'Traet O\'som Orange'),(1317,'BRITTCRAZPIN',0,'Treat Crazy Pineapple',4,'Treat Crazy Pineapple'),(1318,'BRITTJIMJAM',0,'Treat Jim Jam',4,'Treat Jim Jam'),(1400,'CADB5X',0,'5 Star',3,'5 Star'),(1401,'CADB5X3D',0,'5 Star 3D',3,'5 Star 3D'),(1402,'CADBBVB',0,'Born Vita Biscuit',3,'Born Vita Biscuit'),(1403,'CADBCEIB',0,'Cadbury Celebrations',3,'Cadbury Celebrations'),(1404,'CADBSOTS',0,'Cadbury Shots',3,'Cadbury Shots'),(1405,'CADBDMLK',0,'Dairy Milk',3,'Dairy Milk'),(1406,'CADBDMLKL',0,'Dairy Milk Lickables',3,'Dairy Milk Lickables'),(1407,'CADBFUSE',0,'Fuse',3,'Fuse'),(1408,'CADBGEMS',0,'Gems',3,'Gems'),(1409,'ADBGESPSE',0,'Gems Surprise',3,'Gems Surprise'),(1410,'CADBOREO',0,'Oreo',3,'Oreo'),(1411,'CADBPRK',0,'Perk',3,'Perk'),(1500,'HLDALIN1',0,'All in One',2,'All in One'),(1501,'HLDBUJYA',0,'Bhujia',2,'Bhujia'),(1502,'HLDBONDI',0,'Boondi',2,'Boondi'),(1503,'HLDCNAKRK',0,'Chana Cracker',2,'Chana Cracker'),(1504,'HLDGAPSAP',0,'Gup Shup',2,'Gup Shup'),(1505,'HLDNVRTN',0,'Navratan',2,'Navratan'),(1506,'HLDHFMIXT',0,'Halka Fulka Mixture',2,'Halka Fulka Mixture'),(1507,'HLDJHLCHUR',0,'Jhal Chanachur',2,'Jhal Chanachur'),(1508,'HLDKBLCHUR',0,'Kabuli Chana',2,'Kabuli Chana'),(1509,'HLDKHTAMITA',0,'Khatta Mithaa',2,'Khatta Mithaa'),(1510,'HLDMOGDAL',0,'Moong Dal',2,'Moong Dal'),(1511,'HLDNUTCRAK',0,'Nut Crackers',2,'Nut Crackers'),(1512,'HLDPNJTDKA',0,'Punjabi Tadka',2,'Punjabi Tadka'),(1513,'HLDSONPADI',0,'Sonpapdi',2,'Sonpapdi'),(1600,'AMLBUT',0,'Amul Butter',1,'Amul Butter'),(1601,'AMLCHEJ',0,'Amul Cheese',1,'Amul Cheese'),(1602,'AMLCHOC',0,'Amul Chocolate',1,'Amul Chocolate'),(1603,'AMLCOL',0,'Amul Cool',1,'Amul Cool'),(1604,'AMLKSR',0,'Amul Cool Kesar',1,'Amul Cool Kesar'),(1605,'AMLCOWGHE',0,'Amul Cow Ghee',1,'Amul Cow Ghee'),(1606,'AMLGOLD',0,'Amul Gold',1,'Amul Gold'),(1607,'AMLTRTS',0,'Amul Happy Treats',1,'Amul Happy Treats'),(1608,'AMLLASI',0,'Amul Lassi',1,'Amul Lassi'),(1609,'AMLLITE',0,'Amul Lite',1,'Amul Lite'),(1610,'AMLMSTI',0,'Amul Masti',1,'Amul Masti'),(1611,'AMLMMLK',0,'Amul Moti Mlk',1,'Amul Moti Mlk'),(1612,'AMLPNER',0,'Amul Paneer',1,'Amul Paneer'),(1613,'AMLPREM',0,'Amul Premium',1,'Amul Premium'),(1614,'AMLPGHE',0,'Amul Pure Ghee',1,'Amul Pure Ghee'),(1615,'AMLPGP',0,'Amul Pure Ghee Pouch',1,'Amul Pure Ghee Pouch'),(1616,'AMLTZA',0,'Amul Taza',1,'Amul Taza'),(1617,'AMLTZATMLK',0,'Amul Taza Toned Milk',1,'Amul Taza Toned Milk'),(1618,'AMLSPRY',0,'Amulsprey',1,'Amulsprey'),(1619,'AMLMKL',0,'Amulya Milk ',1,'Amulya Milk '),(1620,'AMLFRSCREM',0,'Fresh Cream',1,'Fresh Cream'),(1621,'AMLGLBJAMN',0,'Gulab  Jamun',1,'Gulab  Jamun'),(1622,'AMLKDIDUD',0,'Kadhai Dudh',1,'Kadhai Dudh'),(1623,'AMLMLKSAKE',0,'Milk Shake',1,'Milk Shake'),(1624,'AML ICE',0,'Amul Icecreame',1,'AML ICE');
/*!40000 ALTER TABLE `mst_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-05  0:46:38
