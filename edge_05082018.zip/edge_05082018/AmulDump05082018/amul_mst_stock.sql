-- MySQL dump 10.13  Distrib 5.6.23, for Win32 (x86)
--
-- Host: localhost    Database: amul
-- ------------------------------------------------------
-- Server version	5.7.22-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mst_stock`
--

DROP TABLE IF EXISTS `mst_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_stock` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `discription` varchar(255) DEFAULT NULL,
  `is_active` varchar(255) DEFAULT NULL,
  `item_code` bigint(20) DEFAULT NULL,
  `offer` double DEFAULT NULL,
  `qty` double DEFAULT NULL,
  `rate` double DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `value` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKd3rdpbxnrq2r68v6bi1y292lt` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_stock`
--

LOCK TABLES `mst_stock` WRITE;
/*!40000 ALTER TABLE `mst_stock` DISABLE KEYS */;
INSERT INTO `mst_stock` VALUES (1,'AML BTR','2018-07-25 15:28:38','Amul Butter In 100 gm','T',1600,NULL,33,46,'Amul','NOS',1518),(2,'AMLCL','2018-07-25 15:30:40','Amul Cool Of Kesar','T',1603,NULL,96,18,'Amul','Nos',1728),(3,'AMLGLD','2018-07-25 15:33:41','Amul Gold In 500 gm','T',1606,NULL,2,66,'Amul','Nos',132),(4,'AMLLSI','2018-07-25 15:35:30','Amul Lassi in Tetra Pack','T',1608,NULL,20,15,'Amul India','Nos',300),(5,'AML BTR LTE','2018-07-25 15:38:02','Amul Butter Lite In 100 gm','T',1611,NULL,103,30,'Amul India','Nos',3090),(6,'AMLMTI','2018-07-25 15:39:24','Amul Moti Milk In Full Cream','T',1611,NULL,76,26,'Amul India','Nos',1976),(7,'AMLPNR200GRM','2018-07-25 15:40:35','Amul Paneer In 200 gm','T',1612,NULL,89,66,'Amul India','Nos',5874),(8,'AMLPRM','2018-07-25 15:42:05','Amul Premium In Tetra Pack','T',1613,NULL,53,15,'Amul India','Nos',795),(9,'AMLCRM','2018-07-25 15:43:31','Amul Fresh Cream In 1 ltr','T',1620,NULL,4,182,'Amul India','Nos',728),(10,'AMLSHK','2018-07-25 15:44:55','Amul Milk Shake In Tetra Pack','T',1623,NULL,8,25,'Amul India','Nos',200);
/*!40000 ALTER TABLE `mst_stock` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-05  0:46:38
