package com.boot.edge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.boot.edge.model.Inventory;
import com.boot.edge.model.Product;
import com.boot.edge.mgr.InvtApi;
import com.boot.edge.mgr.ItemApi;
import com.boot.edge.mgr.ProductApi;

@Controller
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private InvtApi invtApi;
	
	@Autowired
	private ProductApi productApi;
	
	@Autowired
	private ItemApi itemApi;

	@RequestMapping(value={"/add"}, method = RequestMethod.GET)
	public ModelAndView loadVoucher() {
		ModelAndView mv = new ModelAndView("voucher");
		return mv;	
	}
	
	@RequestMapping(value={"/list"}, method = RequestMethod.GET)
	public void showInventories() {
		List<Product> productType = productApi.products();
		if (productType != null) {
		for (Product product : productType) {
			System.out.println(product.toString());
		}
		}else {
			System.out.println("Product not found.");
		}
	}
	
	@RequestMapping(value={"/add"}, method = RequestMethod.POST)
	public void addInventory() {
		Inventory invtPram = new Inventory();
		invtApi.addInventory(invtPram);		
	}


	


	
	

	//https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram
	
}
