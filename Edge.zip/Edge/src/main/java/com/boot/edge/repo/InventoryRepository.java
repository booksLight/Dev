package com.boot.edge.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.edge.entity.Inventory;
import com.boot.edge.entity.User;


public interface InventoryRepository extends JpaRepository<Inventory, Long>{

	Inventory findInventoryByInvoice(String invoice);
}
