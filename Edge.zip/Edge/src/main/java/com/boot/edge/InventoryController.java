package com.boot.edge;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.edge.entity.Address;
import com.boot.edge.entity.Contact;
import com.boot.edge.entity.Item;
import com.boot.edge.entity.Profile;
import com.boot.edge.entity.Role;
import com.boot.edge.entity.User;
import com.boot.edge.repo.AddressRepository;
import com.boot.edge.repo.InventoryRepository;
import com.boot.edge.repo.UserRepository;

@RestController
public class InventoryController {

	@Autowired
	private InventoryRepository inventoryRepository;

	
	@GetMapping("/item")
	public Item item() {

		return null;
	}

	@GetMapping("/items")
	public List<Item> getItems() {
		//return userRepository.findAll();
		return null;
	}

	@GetMapping("/item/add")
	public List<Item> addItem() {
		System.out.println("\n ****** adding an Item.....\n");
		
		
		return null ;
	}
	
	@PostMapping("/item/update")
	public void updateItem() {
		System.out.println("\n ****** updating an item.....\n");		
		
		
	}
	

	//https://www.freeprojectz.com/uml/inventory-sales-system-class-diagram
	
}
