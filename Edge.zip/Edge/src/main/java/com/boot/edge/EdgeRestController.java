package com.boot.edge;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.edge.entity.Address;
import com.boot.edge.entity.Contact;
import com.boot.edge.entity.Profile;
import com.boot.edge.entity.Role;
import com.boot.edge.entity.User;
import com.boot.edge.repo.AddressRepository;
import com.boot.edge.repo.UserRepository;

@RestController
public class EdgeRestController {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	AddressRepository adressRepository;

	@GetMapping("/")
	public Map<String, String> welcome() {

		Map<String, String> modelMap = new HashMap<String, String>();
		modelMap.put("Hi", "Welcome to Edge!");

		return modelMap;
	}

	@GetMapping("/users")
	public List<User> getUsers() {
		return userRepository.findAll();
	}

	@GetMapping("/add")
	public List<User> addUser() {
		System.out.println("\n ****** adding an user.....\n");
		
		userRepository.save(registerUser());
		return userRepository.findAll();
	}
	
	@PostMapping("/add")
	public void postUser() {
		System.out.println("\n ****** postUser an user.....\n");		
		userRepository.save(registerUser());
		
	}
	

	
	private User registerUser() {
		
		// Create User
		User user = new User();		
		user.setEmail("test@sharma.com");
		user.setActivated(false);
		user.setProfile(geProfile(user));		
		return user;
	}

	private Profile geProfile(User user) {
		Profile profile = new Profile();
		profile.setFirstName("Rakesh");
		profile.setLastName("Sharma");
		profile.setMobile("8310319984");
		profile.setPassword("test");
		profile.setAddress(getAddress(profile));
		profile.setVerified(false);
		profile.setUser(user);		
		profile.setRoles(getRoles(profile));	
				
		return profile;
	}

	private Collection<Role> getRoles(Profile profile) {
		Collection<Role> roles = new HashSet<Role>();
		roles.add(new Role("ROLE_USER"));
		profile.setRoles(roles);		
		return roles;
	}

	private Collection<Address> getAddress(Profile profile) {
		// Create Address
		Collection<Address> addresses = new HashSet<Address>();
		Address address = new Address();
		address.setHouseNo("72 1st Floor");
		address.setStreatNo("5th Cross");
		address.setCity("Hebbal");
		address.setState("Karnatka");
		address.setPin(560024);
		address.setPhone("223304402");
		address.setActive(true);
		address.setParmanent(false);
		address.setLocal(true);		
		address.setProfile(profile);
		addresses.add(address);
		return addresses;
	}
}
