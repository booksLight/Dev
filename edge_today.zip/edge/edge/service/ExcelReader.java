package com.boot.edge.service;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.boot.edge.ui.StockVO;

public interface ExcelReader {

	public StockVO readXls(String xlsFilePath) throws IOException, InvalidFormatException;
	
}
