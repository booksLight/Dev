package com.boot.edge.service.impl;

import java.io.File;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.boot.edge.service.ExcelReader;
import com.boot.edge.ui.StockVO;

@Service
public class ExcelReaderImpl implements ExcelReader {

	private static final Logger logger = LoggerFactory.getLogger(ExcelReaderImpl.class);

	@Override
	public StockVO readXls(final String xlsFilePath) throws IOException, InvalidFormatException {
		StockVO stockVO = null;
		Integer NO_OF_WROK_BOOKS = 0;

		if (xlsFilePath != null) {
			Workbook workbook;
			workbook = openWorkbook(xlsFilePath);
			NO_OF_WROK_BOOKS = workbook.getNumberOfSheets();
			logger.info("\n Number of Sheets found : " + NO_OF_WROK_BOOKS);
			for (Sheet sheet : workbook) {

				if (hasSheetEnpity(sheet)) {
					logger.info("\n Sheet " + sheet.getSheetName() + " is empty.");
				} else {
					logger.info("\n Sheet title :" + sheet.getSheetName());
					for (Row row : sheet) {
						for (Cell cell : row) {
							stockVO = valuesByCellType(cell, workbook);
						}
						logger.info(" ");
					}
				}
			}

			return stockVO;
		}
		return new StockVO();
	}

	private StockVO valuesByCellType(Cell cell, Workbook workbook) throws IOException, InvalidFormatException {
		StockVO stockVO = new StockVO();
		
		/*stockVO.setProductCode(productCode);
		stockVO.setItemCode(itemCode);
		stockVO.setCode(code);		
		stockVO.setDate(date);
		
		
		
		stockVO.setNumber(number);
		
		
		stockVO.setTitle(title);
		stockVO.setQty(qty);			
		stockVO.setUom(uom);
		stockVO.setRate(rate);
		stockVO.setValue(value);
		stockVO.setOffer(offer);
		stockVO.setIsActive(isActive);
		stockVO.setDiscription(discription);
		*/
		
		switch (cell.getCellTypeEnum()) {
		case BOOLEAN:
			logger.info("" + cell.getBooleanCellValue());
			break;
		case STRING:
			logger.info(cell.getRichStringCellValue().getString());
			break;
		case NUMERIC:
			if (DateUtil.isCellDateFormatted(cell)) {
				logger.info("" + cell.getDateCellValue());
			} else {
				logger.info("" + cell.getNumericCellValue());
			}
			break;
		case FORMULA:
			valueByFormula(cell, workbook, stockVO);
			break;
		case BLANK:
			logger.info("");
			break;
		default:
			logger.info("");
		}
		logger.info(" ");
		return stockVO;
	}

	private void valueByFormula(Cell cell, Workbook workbook, StockVO stockVO)
			throws IOException, InvalidFormatException {
		FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
		CellValue cellValue = evaluator.evaluate(cell);
		int cellType = evaluator.evaluateFormulaCell(cell);
		evaluator.evaluateAll();
		switch (cellType) {
		case Cell.CELL_TYPE_BOOLEAN:
			logger.info("" + cell.getBooleanCellValue());
			break;
		case Cell.CELL_TYPE_STRING:
			logger.info(cell.getRichStringCellValue().getString());
			break;
		case Cell.CELL_TYPE_NUMERIC:
			if (DateUtil.isCellDateFormatted(cell)) {
				logger.info("" + cell.getDateCellValue());
			} else {
				logger.info("" + cell.getNumericCellValue());
			}
			break;
		case Cell.CELL_TYPE_FORMULA:
			// logger.info(cell.getCellFormula());
			logger.info(cell.getStringCellValue());
			break;
		case Cell.CELL_TYPE_BLANK:
			logger.info("");
			break;
		default:
			logger.info("");
		}
	}

	private boolean hasSheetEnpity(Sheet sheet) throws IOException, InvalidFormatException {
		return isCellEmpty(sheet.getRow(3).getCell(3));
	}

	public boolean isCellEmpty(final Cell cell) {
		if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK) {
			return true;
		}

		if (cell.getCellType() == Cell.CELL_TYPE_STRING && cell.getStringCellValue().isEmpty()) {
			return true;
		}

		return false;
	}

	private Workbook openWorkbook(final String xlsFilePath) throws IOException, InvalidFormatException {
		Workbook workbook = WorkbookFactory.create(new File(xlsFilePath));
		return workbook;
	}

}
