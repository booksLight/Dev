const aws = require('aws-sdk') require(id: string) :any
const config = require('./conf.json');


exports.handler = (event, context, callback) => {

(async function(){
	
	try{
		
		aws.config.setPromisesDependency();
		aws.config.update({
			accessKeyId: AKIAIKIC5FRF7LP75AAA,
			secretAccesskey: 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,
			region: 'us-east-1'
		});
		
		const s3 = new aws.S3();
		const response = await s3.listObjectsV2({
			Bucket: 'drishtybucket23022020'
			
		}).promise();
		
		console.log(response);
		
	}catch(e){
		console.log('out error',e);
	}
})();
   
callback(null, "Hello from Lambda");
};

