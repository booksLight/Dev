package com.boot.edge.repo.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.edge.model.master.MasterItem;

public interface MasterItemRepository extends JpaRepository<MasterItem, Long>{

	MasterItem findMasterItemByCode(String code);
	List<MasterItem> findMasterItemByProdId(Long prodeKey);	
}
