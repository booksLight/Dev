package com.boot.edge.mgr;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.boot.edge.model.Item;
import com.boot.edge.model.Stock;
import com.boot.edge.model.master.MasterItem;
import com.boot.edge.repo.ItemRepository;
import com.boot.edge.repo.master.MasterItemRepository;
import com.boot.edge.util.ItemUtil;

@Component
public class ItemManager implements ItemApi {

	@Autowired
	private MasterItemRepository mItemRepository;
	
	@Autowired
	private ItemRepository itemRepository;
	
	@Override
	public void addItem(Item itemPram) {
		Item item = new ItemUtil().initItem();
		if(item != null) {
			System.out.println("ItemRepository invokation : START");
			itemRepository.save(item);
			System.out.println("ItemRepository invokation : END");
		}else {
			System.out.println("Item is null");
		}		
		System.out.println("\n Item added successfully...");		
	}

	@Override
	public Item findItem(Long keyPram) {
		Item it = null;
		Optional<Item> item = itemRepository.findById(keyPram);
		if(item != null & item.isPresent() ) {
			it = item.get();			
			System.out.println("Item found "+it.toString());
			return it;
		}else {
			return it;
		}	
	}
	

	@Override
	public void updateItem(Item itemPram) {
		if(itemPram != null) {
			Item currentItem = findItem(itemPram.getId());
			Item updatedOne = compareUpdat(currentItem, itemPram);
		}

	}
	

	@Override
	public void deleteItem(Long keyPram) {
		Item thisItem = findItem(keyPram);
		if(thisItem != null ) {
			itemRepository.delete(thisItem);
			System.out.println("Item deleted successfully");
		}else {
			System.out.println("Item  not found");
		}		

	}

	@Override
	public  List<Item> items() {
		try{
			return itemRepository.findAll();
		}catch(Exception e) {
			System.out.println("\n\t *****  Exception while listing....\n");
			e.printStackTrace();
		}
		return new ArrayList<Item>();
	}
	
	private Item compareUpdat(Item currentItem, Item itemPram) {
		//currentItem.setId(itemPram.getId());
		currentItem.setNumber(itemPram.getNumber());
		currentItem.setQty(itemPram.getQty());
		currentItem.setType(itemPram.getType());
		currentItem.setDiscount(itemPram.getDiscount());
		
		Collection<Stock> currentstocks =  currentItem.getStocks();
		Collection<Stock> pramstocks =  itemPram.getStocks();
		
		for(Stock cStock : currentstocks) {
			for(Stock pStock : pramstocks) {
				if(cStock.getId().equals(pStock.getId())) {
					doUpdateStock(cStock, pStock);
				}
			}
			System.out.println("\nSTOCK STATUS ="+cStock.toString());
		}
		
		return null;
	}

	private void doUpdateStock(Stock cStock, Stock pStock) {
		cStock.setNumber(pStock.getNumber());
		cStock.setRate(pStock.getRate());
		cStock.setType(pStock.getType());
		cStock.setUom(pStock.getUom());
		cStock.setDiscription(pStock.getDiscription());		
	}

	@Override
	public void addMasterItem(MasterItem mItem) {
		if(mItem!=null) {
			mItemRepository.save(mItem);
		}
		
	}

	@Override
	public MasterItem findMasterItem(Long mItemKey) {
		// TODO Auto-generated method stub		
		return mItemKey >0 ? mItemRepository.getOne(mItemKey):new MasterItem();
	}

	@Override
	public List<MasterItem> mitems() {
		// TODO Auto-generated method stub
		return mItemRepository.findAll();
	}

	@Override
	public void updateMasterItem(MasterItem mItem) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteMasterItem(Long mItemKey) {
		if(mItemKey >0) {
			mItemRepository.deleteById(mItemKey);
		}
		
	}

	@Override
	public List<MasterItem>  findMasterItemByProdId(Long prodeKey) {	
		return prodeKey >0 ? mItemRepository.findMasterItemByProdId(prodeKey):new ArrayList<MasterItem>();
	}

	@Override
	public Map<Long, String> getItemsMap() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<Long, String> getProductItemsMap(Long productKey) {
		Map<Long, String> itemMap = new HashMap<>();
		List<MasterItem> mitemType = mItemRepository.findMasterItemByProdId(productKey);
		
		if(mitemType !=null) {			
			for(MasterItem mitem : mitemType) {
				itemMap.put(mitem.getId(), mitem.getTitle());
			}
		}	
		return itemMap;
	}

}
