package com.boot.edge.util;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import com.boot.edge.model.Inventory;
import com.boot.edge.model.Item;
import com.boot.edge.model.Product;
import com.boot.edge.model.Stock;

public class InvtUtil {

	public Inventory getInventory() {
		Inventory inv = new Inventory();
		inv.setDate(new Timestamp(new Date().getTime()));
		inv.setInvoice("INV-"+Math.random()+new Date().getMonth());
		inv.setValue(120l);
		inv.setStocks(getStocks(inv));
		inv.setStatus(true);
		return inv;
	}


	private Collection<Product> getStocks(Inventory inv) {
		// Create Address
				Collection<Product> products = new HashSet<Product>();
				Product product = new Product();
				product.setBrand("Amul");
				product.setNumber(43750050);
				product.setType("Fast");
				product.setItems(getItems(product));
				product.setInventory(inv);
				products.add(product);				
				return products;
	}
	

	private Collection<Item> getItems(Product product) {
		Collection<Item> items = new HashSet<Item>();
		Item item = new Item();
		item.setNumber(343);
		item.setQty(4.0d);
		item.setType("Milk");
		item.setDiscription("Butter");
		item.setDiscount(new Double(0.00));
		item.setStocks(getStocks(item));	
		items.add(item);
		return items;
	}
		


	private Collection<Stock> getStocks(Item item) {
		Collection<Stock> stocks = new HashSet<Stock>();
		Stock stock = new Stock();
		stock.setNumber(6040);
		stock.setRate(45.8d);
		stock.setType("Editable");
		stock.setUom("NOS");
		stock.setDiscription("Old");
		stock.setItem(item);
		stocks.add(stock);
		return stocks;
	}


}
