
// Get the modal
var billModal = document.getElementById('billModal');
var stockModal = document.getElementById('stockModal');
var itemModal = document.getElementById('itemModal');
var prodModal = document.getElementById('prodModal');
var repoModal = document.getElementById('repoModal');
var uploadModal = document.getElementById('uploadModal');

// Get the button that opens the modal
var billBtn = document.getElementById("billBtn");
var stockBtn = document.getElementById("stockBtn");
var itemBtn = document.getElementById("itemBtn");
var prodBtn = document.getElementById("prodBtn");
var repoBtn = document.getElementById("repoBtn");
var uploadBtn = document.getElementById("uploadBtn");


// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];
var spanBill = document.getElementById("billX");
var spanStock = document.getElementById("stockX");
var spanItem = document.getElementById("itemX");
var spanProd = document.getElementById("prodX");
var spanRepo = document.getElementById("repoX");
var spanUpload = document.getElementById("uploadX");


// When the user clicks the button, open the modal 
billBtn.onclick = function() {
	billModal.style.display = "block";
}
stockBtn.onclick = function() {
	stockModal.style.display = "block";
}
itemBtn.onclick = function() {
	itemModal.style.display = "block";
}
prodBtn.onclick = function() {
	prodModal.style.display = "block";
}
repoBtn.onclick = function() {
	repoModal.style.display = "block";
}
uploadBtn.onclick = function() {
	uploadModal.style.display = "block";
}


// When the user clicks on <span> (x), close the modal
span.onclick = function() {
	billModal.style.display = "none";	
}
spanBill.onclick = function() {
	billModal.style.display = "none";	
}
spanStock.onclick = function() {
	stockModal.style.display = "none";	
}
spanItem.onclick = function() {
	itemModal.style.display = "none";	
}
spanProd.onclick = function() {
	prodModal.style.display = "none";	
}
spanRepo.onclick = function() {
	repoModal.style.display = "none";	
}
spanUpload.onclick = function() {
	uploadModal.style.display = "none";	
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == billModal) {
    	billModal.style.display = "none";
    }
    if (event.target == stockModal) {
    	stockModal.style.display = "none";
    }
    if (event.target == itemModal) {
    	itemModal.style.display = "none";
    }
    if (event.target == prodModal) {
    	prodModal.style.display = "none";
    }
    if (event.target == repoModal) {
    	repoModal.style.display = "none";
    }
    if (event.target == uploadModal) {
    	uploadModal.style.display = "none";
    }
    
    $(function() { $("#e1").daterangepicker(); });
}