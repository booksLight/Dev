$(document)
		.ready(
				function() {
					var table = "";
					var products = "";
					var product = "";
					var items = "";
					var item = "";
					var stocks = "";
					var stock = "";
					var sdesc = "";
					var sqty = "";
					var suom = "";
					var svalue = "";
					var str = "";
					var key = "";
					table = document.getElementById("ecart");
					appendHeader(table);

					$('#add2Cart')
							.click(
									function(e) {

										products = document
												.getElementById("selectProduct");
										prod = products.options[products.selectedIndex];

										items = document
												.getElementById("selectItem");
										item = items.options[items.selectedIndex];

										stocks = document
												.getElementById("selectStock");
										stock = stocks.options[stocks.selectedIndex];
										stockv = stocks.options[stocks.selectedIndex].value;
										sdesc = document
												.getElementById("stockDiscription").value;
										sqty = document
												.getElementById("stockQty").value;
										suom = document
												.getElementById("stockUom").value;
										svalue = document
												.getElementById("stockSum").value;

										key = prod.value + "_" + item.value
												+ "_" + stock.value;

										str = stock.text + ", " + sdesc + ", "
												+ sqty + ", " + suom + ", "
												+ svalue;

										append(table);
									});

					$('#btnSubmit').click(function(e) {
						var myTab = document.getElementById('ecart');
						showTableData(myTab)						
						return false;
					});

					function append(table) {
						var tr = createTR();

						tr.appendChild(createTDID("1%"));
						tr.appendChild(createTDStock("10%"));
						tr.appendChild(createTDDesc("15%"));
						tr.appendChild(createTDQty("20%"));
						tr.appendChild(createTDUom("20%"));
						tr.appendChild(createTDValue("15%"));
						tr.appendChild(createTD("20%"));
						tr.style.border = "1";

						table.appendChild(tr);

					}

					function createTH() {
						return document.createElement("th");
					}

					function createTR() {
						return document.createElement("tr");
					}

					function createTDID(s) {
						var td = document.createElement("td");
						td.style.width = s;
						td.style.border = "1";
						td.style.display = "none";
						td.appendChild(createNodeID(1));
						return td;
					}

					function createTDStock(s) {
						var td = document.createElement("td");
						td.style.width = s;
						td.style.border = "1";
						td.appendChild(createNodeStock(1));
						return td;
					}

					function createTDDesc(s) {
						var td = document.createElement("td");
						td.style.width = s;
						td.style.border = "1";
						td.appendChild(createNodeSdesc(2));
						return td;
					}

					function createTDQty(s) {
						var td = document.createElement("td");
						td.style.width = s;
						td.style.border = "1";
						td.appendChild(createNodeSqty(3));
						return td;
					}

					function createTDUom(s) {
						var td = document.createElement("td");
						td.style.width = s;
						td.style.border = "1";
						td.appendChild(createNodeSuom(4));
						return td;
					}

					function createTDValue(s) {
						var td = document.createElement("td");
						td.style.width = s;
						td.style.border = "1";
						td.appendChild(createNodeSvalue(5));
						return td;
					}

					function createTD(s) {
						var td = document.createElement("td");
						td.style.width = s;
						td.style.border = "1";
						td.appendChild(createNodeCommon(1));
						return td;
					}

					function createNodeID(v) {
						return document.createTextNode(key);
					}
					function createNodeStock(v) {
						return document.createTextNode(stock.text + ":" + v);
					}
					function createNodeSdesc(v) {
						return document.createTextNode(sdesc + ":" + v);
					}

					function createNodeSqty(v) {
						return document.createTextNode(sqty + ":" + v);
					}

					function createNodeSuom(v) {
						return document.createTextNode(suom + ":" + v);
					}

					function createNodeSvalue(v) {
						return document.createTextNode(svalue + ":" + v);
					}
					function createNodeCommon(v) {

						var element = document.createElement("input");
						element.type = "button";
						element.value = "Delete"; // Really? You want the
													// default value to be the
													// type string?
						element.name = "bd"; // And the name too?
						element.onclick = function() {
							$(this).parents("tr").remove();
						};
						return element;
					}

					function appendHeader(table) {
						var tr = createTR();
						tr.appendChild(createTHID("1%"));
						tr.appendChild(createTHStock("10%"));
						tr.appendChild(createTHDesc("15%"));
						tr.appendChild(createTHQty("20%"));
						tr.appendChild(createTHUom("20%"));
						tr.appendChild(createTHValue("15%"));
						tr.appendChild(createTH("20%"));
						tr.style.border = "3";

						table.appendChild(tr);
					}

					function createTHID(s) {
						var th = document.createElement("th");
						th.style.width = s;
						th.style.border = "1";
						th.style.display = "none";
						th.style.backgroundColor = "#CDF130";
						th.appendChild(document.createTextNode("KEY"));
						return th;
					}
					function createTHStock(s) {
						var th = document.createElement("th");
						th.style.width = s;
						th.style.border = "1";
						th.style.backgroundColor = "#CDF130";
						th.appendChild(document.createTextNode("PRODUCT"));
						return th;
					}

					function createTHDesc(s) {
						var th = document.createElement("th");
						th.style.width = s;
						th.style.border = "1";
						th.style.backgroundColor = "#CDF130";
						th.appendChild(document.createTextNode("DESCRIPTION"));
						return th;
					}

					function createTHQty(s) {
						var th = document.createElement("th");
						th.style.width = s;
						th.style.border = "1";
						th.style.backgroundColor = "#CDF130";
						th.appendChild(document.createTextNode("QTY"));
						return th;
					}

					function createTHUom(s) {
						var th = document.createElement("th");
						th.style.width = s;
						th.style.border = "1";
						th.style.backgroundColor = "#CDF130";
						th.appendChild(document.createTextNode("UOM"));
						return th;
					}

					function createTHValue(s) {
						var th = document.createElement("th");
						th.style.width = s;
						th.style.border = "1";
						th.style.backgroundColor = "#CDF130";
						th.appendChild(document.createTextNode("VALUE"));
						return th;
					}
					function createTH(s) {
						var th = document.createElement("th");
						th.style.width = s;
						th.style.border = "1";
						th.style.backgroundColor = "#CDF130";
						th.appendChild(document.createTextNode("1Header"));
						return th;
					}

					function showTableData(myTab) {
						document.getElementById('info').innerHTML = "";
						jsonObj = [];
						// LOOP THROUGH EACH ROW OF THE TABLE AFTER HEADER.
						for (i = 1; i < myTab.rows.length; i++) {

							// GET THE CELLS COLLECTION OF THE CURRENT ROW.
							var objCells = myTab.rows.item(i).cells;
							item = {}
							// LOOP THROUGH EACH CELL OF THE CURENT ROW TO READ CELL VALUES.
							for (var j = 0; j < objCells.length; j++) {

								if (j == 0)
									item["key"] = objCells.item(j).innerHTML;
								if (j == 1)
									item["product"] = objCells.item(j).innerHTML;
								if (j == 2)
									item["description"] = objCells.item(j).innerHTML;
								if (j == 3)
									item["qty"] = objCells.item(j).innerHTML;
								if (j == 4)
									item["uom"] = objCells.item(j).innerHTML;
								if (j == 5)
									item["value"] = objCells.item(j).innerHTML;
							}

							jsonObj.push(item);
						}

						info.innerHTML = JSON.stringify(jsonObj) + '<br />'; // ADD A BREAK (TAG).    
						// alert(JSON.stringify(jsonObj));
						
						var findItemURL = "/item/list/";
						
						$.ajax({
							url : findItemURL+prodId,
							type : 'POST',
							async:false ,
							success : function(result) {						
								
								$.each(result, function(key, val) {
									
								})
								
							},
							error : function() {
								alert("Whooaaa! Something went wrong while billing..")
							},
						});
						
						
						
						
						
						//END
					}
				});